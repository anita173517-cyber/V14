package com.harindra.tvlauncher

import org.junit.Assert.assertEquals
import org.junit.Test

class M3uRepositoryTest {

    @Test
    fun parseM3uText_parsesExtendedMetadataAndHeaders() {
        val sample = """
            #EXTM3U
            #EXTINF:-1 tvg-logo="https://example.com/sports.png" group-title="Sports HD",Star Sports 1 HD
            #EXTVLCOPT:http-user-agent=RAMPlayer/25.0
            #EXTVLCOPT:http-referrer=https://ref.example.com/
            https://stream.example.com/live/sports1.m3u8
            #EXTINF:-1 group-title="News",NDTV India
            https://stream.example.com/live/news.ts
        """.trimIndent()

        val channels = M3uRepository.parseM3uText(sample)
        assertEquals(2, channels.size)
        assertEquals("Star Sports 1 HD", channels[0].name)
        assertEquals("Sports HD", channels[0].group)
        assertEquals("https://example.com/sports.png", channels[0].logoUrl)
        assertEquals("RAMPlayer/25.0", channels[0].userAgent)
        assertEquals("https://ref.example.com/", channels[0].referrer)
        assertEquals("NDTV India", channels[1].name)
        assertEquals("News", channels[1].group)
    }
}
