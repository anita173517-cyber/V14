package com.harindra.tvlauncher

import android.app.Application
import java.util.concurrent.Executors

class UltraTvApplication : Application() {

    companion object {
        @Volatile
        var preloadedApps: List<AppItem> = emptyList()
    }

    override fun onCreate() {
        super.onCreate()
        Executors.newSingleThreadExecutor().execute {
            try {
                val prefs = PrefsManager(applicationContext)
                val tier = PerformanceTier.resolve(applicationContext, prefs)
                MediaImageLoader.initForTier(tier)
                preloadedApps = prefs.getCachedApps()
            } catch (_: Throwable) { }
        }
    }
}
