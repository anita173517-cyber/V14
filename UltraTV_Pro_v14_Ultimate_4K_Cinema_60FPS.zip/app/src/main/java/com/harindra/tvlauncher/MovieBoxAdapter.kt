package com.harindra.tvlauncher

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.graphics.Outline
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class MovieBoxAdapter(
    private val prefs: PrefsManager,
    private val onClick: (MovieBoxItem) -> Unit,
    private val onLongClick: ((MovieBoxItem) -> Unit)? = null,
    private val onItemFocused: ((String, Int) -> Unit)? = null
) : ListAdapter<MovieBoxItem, MovieBoxAdapter.MbHolder>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<MovieBoxItem>() {
            override fun areItemsTheSame(a: MovieBoxItem, b: MovieBoxItem) = a.id == b.id
            override fun areContentsTheSame(a: MovieBoxItem, b: MovieBoxItem) = a == b
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MbHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_moviebox_card, parent, false)
        return MbHolder(v)
    }

    override fun onBindViewHolder(holder: MbHolder, position: Int) {
        holder.bind(getItem(position))
    }

    override fun onViewRecycled(holder: MbHolder) {
        super.onViewRecycled(holder)
        MediaImageLoader.cancelRequest(holder.ivPoster)
    }

    inner class MbHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivPoster: ImageView = itemView.findViewById<ImageView>(R.id.ivMbPoster).apply {
            val r = 18f * resources.displayMetrics.density
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, r)
                }
            }
            clipToOutline = true
        }
        private val tvTitle: TextView = itemView.findViewById(R.id.tvMbTitle)
        private val tvMeta: TextView = itemView.findViewById(R.id.tvMbMeta)
        private val tvRating: TextView = itemView.findViewById(R.id.tvMbRating)

        fun bind(item: MovieBoxItem) {
            val isFav = item.title in prefs.getFavoriteMovieTitles()
            tvTitle.text = if (isFav) "★ ${item.title}" else item.title
            tvMeta.text = item.meta
            tvRating.text = item.rating
            if (item.posterUrl.isNotBlank()) {
                MediaImageLoader.loadRemoteImage(item.posterUrl, ivPoster, item.posterResId, 460)
            } else {
                MediaImageLoader.loadLocalBackdropRes(item.posterResId, ivPoster, PerformanceTier.resolve(itemView.context, prefs))
            }
            itemView.setOnClickListener { onClick(item) }
            itemView.setOnLongClickListener { onLongClick?.invoke(item); true }
            itemView.setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_MENU) {
                    onLongClick?.invoke(item); true
                } else false
            }
            itemView.setOnFocusChangeListener { v, hasFocus ->
                val tier = PerformanceTier.resolve(v.context, prefs)
                Animation4D.applyTierFocus(v, hasFocus, tier, prefs.enable4dAnimations)
                if (hasFocus && tier.enableDynamicBackdrop) onItemFocused?.invoke(item.posterUrl, item.posterResId)
            }
        }
    }
}
