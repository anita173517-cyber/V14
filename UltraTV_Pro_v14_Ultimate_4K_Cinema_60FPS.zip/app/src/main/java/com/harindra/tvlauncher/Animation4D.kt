package com.harindra.tvlauncher

import android.view.View
import android.widget.ImageView

object Animation4D {

    // Zero-lag instant hardware scale on TV GPUs (0 dropped frames on Hikeen/Mali GPUs!)
    fun applyTierFocus(view: View, hasFocus: Boolean, tier: PerformanceTier, enableAnim: Boolean) {
        val s = if (hasFocus) tier.focusScale else 1.0f
        if (!enableAnim || tier.id <= PerformanceTier.BALANCED.id) {
            view.scaleX = s
            view.scaleY = s
            return
        }
        view.animate().cancel()
        view.animate().scaleX(s).scaleY(s).setDuration(85L).start()
    }

    fun apply4dFocus(view: View, hasFocus: Boolean, ultraLite: Boolean, scaleTarget: Float = 1.05f) {
        val s = if (hasFocus) scaleTarget else 1.0f
        view.scaleX = s
        view.scaleY = s
    }

    fun animateKenBurnsHero(imageView: ImageView, enableKenBurns: Boolean) {
        imageView.animate().cancel()
        imageView.alpha = 1.0f
        imageView.scaleX = 1.0f
        imageView.scaleY = 1.0f
    }

    fun animateTabEntrance(view: View, ultraLite: Boolean) {
        view.alpha = 1f
        view.translationY = 0f
    }
}
