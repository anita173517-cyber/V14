package com.harindra.tvlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class HomeOverrideAccessibilityService : AccessibilityService() {

    private var stockHomePackages: Set<String> = emptySet()
    private var lastLaunchMs = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        refreshStockHomePackages()
    }

    private fun refreshStockHomePackages() {
        val found = mutableSetOf<String>()
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val list = packageManager.queryIntentActivities(homeIntent, 0)
            for (ri in list) {
                val pkg = ri.activityInfo?.packageName?.lowercase() ?: continue
                if (pkg != packageName.lowercase() && !pkg.contains("settings")) {
                    found.add(pkg)
                }
            }
        } catch (_: Throwable) { }
        stockHomePackages = found
    }

    /**
     * Intercepts TV Remote HOME button directly BEFORE HikeenLauncher can open!
     */
    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event != null && event.keyCode == KeyEvent.KEYCODE_HOME) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                launchUltraTvInstant()
            }
            // Consume HOME key so HikeenLauncher NEVER opens on HOME press!
            return true
        }
        return super.onKeyEvent(event)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString()?.lowercase() ?: return
        if (pkg == packageName.lowercase()) return
        if (pkg == "android" || pkg == "com.android.systemui" || pkg.contains("settings")) return

        if (stockHomePackages.isEmpty()) {
            refreshStockHomePackages()
        }

        val isStockHome = pkg in stockHomePackages ||
            pkg.contains("hikeen") ||
            pkg == "com.google.android.tvlauncher" ||
            pkg == "com.google.android.apps.tv.launcherx" ||
            pkg == "com.mitv.tvhome" ||
            pkg == "com.tcl.cyberui" ||
            pkg == "com.sony.dtv.homelauncher" ||
            pkg == "com.hisense.tv.launcher" ||
            pkg.endsWith(".tvlauncher") ||
            pkg.endsWith(".launcher") ||
            pkg.endsWith(".launcher3")

        if (isStockHome) {
            launchUltraTvInstant()
        }
    }

    private fun launchUltraTvInstant() {
        val now = System.currentTimeMillis()
        if (now - lastLaunchMs < 150L) return
        lastLaunchMs = now

        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
        }
        try {
            startActivity(intent)
        } catch (_: Throwable) { }
    }

    override fun onInterrupt() { }
}
