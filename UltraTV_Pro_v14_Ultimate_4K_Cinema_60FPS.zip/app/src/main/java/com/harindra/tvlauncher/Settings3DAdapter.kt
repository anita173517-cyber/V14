package com.harindra.tvlauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Setting3DItem(
    val id: Int,
    val iconRes: Int,
    val title: String,
    val subtitle: String,
    val badge: String
)

class Settings3DAdapter(
    private val items: List<Setting3DItem>,
    private val onClick: (Setting3DItem) -> Unit
) : RecyclerView.Adapter<Settings3DAdapter.Holder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_setting_3d, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.ivIcon.setImageResource(item.iconRes)
        holder.tvTitle.text = item.title
        holder.tvSub.text = item.subtitle
        holder.tvBadge.text = item.badge
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            Animation4D.apply4dFocus(v, hasFocus, false, 1.03f)
        }
    }

    override fun getItemCount(): Int = items.size

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val ivIcon: ImageView = v.findViewById(R.id.ivSettingIcon)
        val tvTitle: TextView = v.findViewById(R.id.tvSettingTitle)
        val tvSub: TextView = v.findViewById(R.id.tvSettingSub)
        val tvBadge: TextView = v.findViewById(R.id.tvSettingBadge)
    }
}
