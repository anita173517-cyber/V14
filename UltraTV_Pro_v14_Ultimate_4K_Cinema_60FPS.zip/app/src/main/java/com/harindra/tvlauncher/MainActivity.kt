package com.harindra.tvlauncher

import android.app.Activity
import android.app.ActivityManager
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Outline
import android.view.ViewOutlineProvider
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQ_VOICE_SEARCH = 2001
        private const val RAM_PLAYER_PKG = "com.harindra.iptvpro"
    }

    private lateinit var prefs: PrefsManager

    // Root & Hero Backdrop
    private lateinit var rootContainer: FrameLayout
    private lateinit var heroBackdropLayer: FrameLayout
    private lateinit var ivHeroBackdrop: ImageView
    private lateinit var heroOverlayBox: LinearLayout
    private lateinit var tvHeroBadge: TextView
    private lateinit var tvHeroTitle: TextView
    private lateinit var tvHeroSubtitle: TextView
    private lateinit var btnHeroPlay: TextView
    private lateinit var btnHeroNext: TextView
    private lateinit var heroDotsContainer: LinearLayout

    // Top Bar
    private lateinit var tabHome: TextView
    private lateinit var tabMovies: TextView
    private lateinit var tabSeries: TextView
    private lateinit var tabLive: TextView
    private lateinit var tabApps: TextView
    private lateinit var tabLibrary: TextView
    private lateinit var btnSearch: View
    private lateinit var btnVoiceSearch: View
    private lateinit var tvWeather: TextView
    private lateinit var btnRamBoost: View
    private lateinit var tvRamStatus: TextView
    private lateinit var btnTopTvSettings: View
    private lateinit var btnSettings: View
    private lateinit var btnProfile: TextView
    private lateinit var btnNetwork: View
    private lateinit var ivWifi: ImageView
    private lateinit var tvNetLabel: TextView
    private lateinit var btnClock: View
    private lateinit var tvClock: TextView
    private lateinit var tvDate: TextView

    // Left 3D Sidebar
    private lateinit var leftSidebarContainer: View
    private lateinit var sideHome: LinearLayout
    private lateinit var sideMovies: LinearLayout
    private lateinit var sideSeries: LinearLayout
    private lateinit var sideLive: LinearLayout
    private lateinit var sideApps: LinearLayout
    private lateinit var sideRealTvSettings: LinearLayout
    private lateinit var sideSettings: LinearLayout

    // Search
    private lateinit var searchBarContainer: LinearLayout
    private lateinit var etSearch: EditText
    private lateinit var btnCloseSearch: TextView
    private lateinit var viewSearchResults: LinearLayout
    private lateinit var tvSearchYtCount: TextView
    private lateinit var rvSearchYoutube: RecyclerView
    private lateinit var tvSearchChannelCount: TextView
    private lateinit var rvSearchChannels: RecyclerView
    private lateinit var tvSearchResultCount: TextView
    private lateinit var rvSearchResults: RecyclerView

    // Tab Views
    private lateinit var viewHome: LinearLayout
    private lateinit var viewCinema: LinearLayout
    private lateinit var viewLive: LinearLayout
    private lateinit var viewApps: LinearLayout
    private lateinit var viewLibrary: LinearLayout

    // Home Rows
    private lateinit var rvPinnedApps: RecyclerView
    private lateinit var continueSection: LinearLayout
    private lateinit var btnSyncWatchNext: TextView
    private lateinit var rvContinueWatching: RecyclerView
    private lateinit var movieBoxSection: LinearLayout
    private lateinit var btnOpenMovieBoxApp: TextView
    private lateinit var rvMovieBoxRecs: RecyclerView
    private lateinit var btnRefreshYt: TextView
    private lateinit var rvYoutubeTrending: RecyclerView
    private lateinit var homeLiveSection: LinearLayout
    private lateinit var tvHomeLiveHeader: TextView
    private lateinit var btnHomeSeeAllLive: TextView
    private lateinit var rvHomeLiveChannels: RecyclerView
    private lateinit var recentAppsSection: LinearLayout
    private lateinit var rvRecentApps: RecyclerView
    private lateinit var rvAllRow: RecyclerView

    // Movies / Series Tab
    private lateinit var tvCinemaTitle: TextView
    private lateinit var tvCinemaSub: TextView
    private lateinit var rvCinemaVideos: RecyclerView
    private lateinit var rvCinemaApps: RecyclerView

    // Live TV Tab
    private lateinit var tvLiveTabTitle: TextView
    private lateinit var btnLiveAddM3u: TextView
    private lateinit var btnLiveRefreshM3u: TextView
    private lateinit var btnLiveChoosePlayer: TextView
    private lateinit var liveCategoryBar: LinearLayout
    private lateinit var tvLiveChannelsSubtitle: TextView
    private lateinit var rvLiveChannelsGrid: RecyclerView
    private lateinit var rvLiveApps: RecyclerView

    // Apps & Library
    private lateinit var tvAppsTitle: TextView
    private lateinit var btnFilterAll: TextView
    private lateinit var btnFilterTv: TextView
    private lateinit var btnFilterSideload: TextView
    private lateinit var rvAllGrid: RecyclerView
    private lateinit var tvDeviceHealth: TextView
    private lateinit var tvFavMoviesHeader: TextView
    private lateinit var rvLibraryFavMovies: RecyclerView
    private lateinit var tvFavChannelsHeader: TextView
    private lateinit var rvLibraryFavChannels: RecyclerView
    private lateinit var rvLibraryFavorites: RecyclerView

    // Adapters
    private lateinit var pinnedAdapter: AppAdapter
    private lateinit var recentAppsAdapter: AppAdapter
    private lateinit var allRowAdapter: AppAdapter
    private lateinit var cinemaAppsAdapter: AppAdapter
    private lateinit var liveAppsAdapter: AppAdapter
    private lateinit var allGridAdapter: AppAdapter
    private lateinit var libraryFavAdapter: AppAdapter
    private lateinit var searchAppsAdapter: AppAdapter

    private lateinit var continueAdapter: ContinueWatchingAdapter
    private lateinit var movieBoxAdapter: MovieBoxAdapter
    private lateinit var libraryFavMoviesAdapter: MovieBoxAdapter
    private lateinit var ytTrendingAdapter: YouTubeAdapter
    private lateinit var cinemaVideosAdapter: YouTubeAdapter
    private lateinit var searchYtAdapter: YouTubeAdapter

    private lateinit var homeChannelsAdapter: ChannelAdapter
    private lateinit var liveChannelsAdapter: ChannelAdapter
    private lateinit var libraryFavChannelsAdapter: ChannelAdapter
    private lateinit var searchChannelsAdapter: ChannelAdapter

    // State
    private var allInstalledApps: List<AppItem> = emptyList()
    private var allLiveChannels: List<LiveChannel> = emptyList()
    private var allYouTubeVideos: List<YouTubeVideo> = emptyList()
    private var allMovieBoxRecs: List<MovieBoxItem> = emptyList()
    private var heroSlides: List<HeroSlide> = emptyList()
    private var heroSlideIndex = 0
    private var currentLiveGroup = "All"
    private var currentTab = 0
    private var currentAppFilter = 0

    private val bgExecutor = Executors.newFixedThreadPool(3)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val themes = listOf(
        "Google TV 2026 Charcoal (Fastest)" to R.drawable.bg_gtv26_base,
        "Midnight Sapphire" to R.drawable.bg_theme_midnight,
        "AMOLED Pure Black (512MB Best)" to R.drawable.bg_theme_amoled,
        "Emerald Neon" to R.drawable.bg_theme_emerald,
        "Royal Violet 4D" to R.drawable.bg_theme_royal,
        "Cinema Crimson" to R.drawable.bg_theme_crimson,
        "Cyber Gold 3D" to R.drawable.bg_theme_cybergold,
        "Deep Ocean 4D" to R.drawable.bg_theme_deepocean
    )

    private val liveTvKeywords = listOf(
        "iptv", "ramplayer", "harindra", "tivimate", "ott", "live", "tv",
        "jio", "hotstar", "sonyliv", "zee5", "youtube", "vlc", "kodi",
        "mxplayer", "smarttube", "stremio", "netflix", "prime", "airtel",
        "tata", "sunnxt", "fancode", "mpv", "nova"
    )

    // Packages NEVER touched by RAM Boost (100% Wi-Fi, Ethernet & IPTV safe!)
    private val ramBoostProtectedPrefixes = listOf(
        "com.android.settings",
        "com.android.tv.settings",
        "com.android.systemui",
        "com.android.networkstack",
        "com.google.android.networkstack",
        "com.android.wifi",
        "com.google.android.wifi",
        "com.android.providers",
        "com.android.bluetooth",
        "android",
        RAM_PLAYER_PKG
    )

    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClockAndStatus()
            mainHandler.postDelayed(this, 10_000L)
        }
    }

    // Auto-refresh MovieBox + YouTube LIVE recommendations every 60 seconds (1 minute)!
    private val liveFeedAutoRefreshRunnable = object : Runnable {
        override fun run() {
            if (getNetworkStatus().second) {
                loadMovieBoxRecsAsync()
                fetchLiveYouTubeAsync()
            }
            mainHandler.postDelayed(this, 60_000L)
        }
    }

    private val heroRotateRunnable = object : Runnable {
        override fun run() {
            if (!prefs.isUltraLiteMode && prefs.showHeroBanner && currentTab == 0 && heroSlides.size > 1) {
                heroSlideIndex = (heroSlideIndex + 1) % heroSlides.size
                renderHeroSlide()
            }
            mainHandler.postDelayed(this, 9_500L)
        }
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadAppsAsync()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableTrueEdgeToEdgeFullscreen()
        setContentView(R.layout.activity_main)
        prefs = PrefsManager(this)
        MediaImageLoader.initForDevice(this)

        bindViews()
        setupAdapters()
        setupListeners()
        applyUserPreferences()
        updateClockAndStatus()

        // Instant <50ms first-frame render from cached apps + curated MovieBox & YouTube
        val cachedApps = UltraTvApplication.preloadedApps.ifEmpty { prefs.getCachedApps() }
        if (cachedApps.isNotEmpty()) {
            allInstalledApps = cachedApps
            refreshUiLists()
        }
        allMovieBoxRecs = MovieBoxEngine.getCuratedMovieBoxCatalog()
        movieBoxAdapter.submitList(allMovieBoxRecs)
        allYouTubeVideos = YouTubeRepository.getInstantCuratedVideos()
        ytTrendingAdapter.submitList(allYouTubeVideos)
        rebuildHeroSlides()
        selectTab(0)

        // Paint first frame IMMEDIATELY (<0.2s), then run background scans staggered!
        mainHandler.postDelayed({
            loadAppsAsync()
            loadCachedChannelsAsync()
        }, 120L)
        mainHandler.postDelayed({
            loadMovieBoxRecsAsync()
            fetchLiveYouTubeAsync()
            fetchWeatherAsync()
        }, 900L)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(packageReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(packageReceiver, filter)
        }
    }


    private fun enableTrueEdgeToEdgeFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableTrueEdgeToEdgeFullscreen()
    }

    override fun onResume() {
        super.onResume()
        LauncherHomeManager.checkAndToastConfirmationOnResume(this)
        updateClockAndStatus()
        if (prefs.isAutoRamGuard && getRamInfo().first < 85L) {
            MediaImageLoader.trimMemory()
        }
        mainHandler.post(clockRunnable)
        mainHandler.postDelayed(heroRotateRunnable, 9_500L)
        mainHandler.postDelayed(liveFeedAutoRefreshRunnable, 60_000L)
        refreshUiLists()
        refreshChannelLists()
        refreshContinueWatchingAsync()
        rebuildHeroSlides()
    }

    override fun onPause() {
        super.onPause()
        mainHandler.removeCallbacks(clockRunnable)
        mainHandler.removeCallbacks(heroRotateRunnable)
        mainHandler.removeCallbacks(liveFeedAutoRefreshRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(packageReceiver) } catch (_: Throwable) {}
        bgExecutor.shutdownNow()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_MODERATE) {
            MediaImageLoader.trimMemory()
        }
    }

    private fun bindViews() {
        rootContainer = findViewById(R.id.rootContainer)
        heroBackdropLayer = findViewById(R.id.heroBackdropLayer)
        val heroRad = 24f * resources.displayMetrics.density
        heroBackdropLayer.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, heroRad)
            }
        }
        heroBackdropLayer.clipToOutline = true
        ivHeroBackdrop = findViewById(R.id.ivHeroBackdrop)
        heroOverlayBox = findViewById(R.id.heroOverlayBox)
        tvHeroBadge = findViewById(R.id.tvHeroBadge)
        tvHeroTitle = findViewById(R.id.tvHeroTitle)
        tvHeroSubtitle = findViewById(R.id.tvHeroSubtitle)
        btnHeroPlay = findViewById(R.id.btnHeroPlay)
        btnHeroNext = findViewById(R.id.btnHeroNext)
        heroDotsContainer = findViewById(R.id.heroDotsContainer)

        tabHome = findViewById(R.id.tabHome)
        tabMovies = findViewById(R.id.tabMovies)
        tabSeries = findViewById(R.id.tabSeries)
        tabLive = findViewById(R.id.tabLive)
        tabApps = findViewById(R.id.tabApps)
        tabLibrary = findViewById(R.id.tabLibrary)
        btnSearch = findViewById(R.id.btnSearch)
        btnVoiceSearch = findViewById(R.id.btnVoiceSearch)
        tvWeather = findViewById(R.id.tvWeather)
        btnRamBoost = findViewById(R.id.btnRamBoost)
        tvRamStatus = findViewById(R.id.tvRamStatus)
        btnTopTvSettings = findViewById(R.id.btnTopTvSettings)
        btnSettings = findViewById(R.id.btnSettings)
        btnProfile = findViewById(R.id.btnProfile)
        btnNetwork = findViewById(R.id.btnNetwork)
        ivWifi = findViewById(R.id.ivWifi)
        tvNetLabel = findViewById(R.id.tvNetLabel)
        btnClock = findViewById(R.id.btnClock)
        tvClock = findViewById(R.id.tvClock)
        tvDate = findViewById(R.id.tvDate)

        leftSidebarContainer = findViewById(R.id.leftSidebarContainer)
        sideHome = findViewById(R.id.sideHome)
        sideMovies = findViewById(R.id.sideMovies)
        sideSeries = findViewById(R.id.sideSeries)
        sideLive = findViewById(R.id.sideLive)
        sideApps = findViewById(R.id.sideApps)
        sideRealTvSettings = findViewById(R.id.sideRealTvSettings)
        sideSettings = findViewById(R.id.sideSettings)

        searchBarContainer = findViewById(R.id.searchBarContainer)
        etSearch = findViewById(R.id.etSearch)
        btnCloseSearch = findViewById(R.id.btnCloseSearch)
        viewSearchResults = findViewById(R.id.viewSearchResults)
        tvSearchYtCount = findViewById(R.id.tvSearchYtCount)
        rvSearchYoutube = findViewById(R.id.rvSearchYoutube)
        tvSearchChannelCount = findViewById(R.id.tvSearchChannelCount)
        rvSearchChannels = findViewById(R.id.rvSearchChannels)
        tvSearchResultCount = findViewById(R.id.tvSearchResultCount)
        rvSearchResults = findViewById(R.id.rvSearchResults)

        viewHome = findViewById(R.id.viewHome)
        viewCinema = findViewById(R.id.viewCinema)
        viewLive = findViewById(R.id.viewLive)
        viewApps = findViewById(R.id.viewApps)
        viewLibrary = findViewById(R.id.viewLibrary)

        rvPinnedApps = findViewById(R.id.rvPinnedApps)
        continueSection = findViewById(R.id.continueSection)
        btnSyncWatchNext = findViewById(R.id.btnSyncWatchNext)
        rvContinueWatching = findViewById(R.id.rvContinueWatching)
        movieBoxSection = findViewById(R.id.movieBoxSection)
        btnOpenMovieBoxApp = findViewById(R.id.btnOpenMovieBoxApp)
        rvMovieBoxRecs = findViewById(R.id.rvMovieBoxRecs)
        btnRefreshYt = findViewById(R.id.btnRefreshYt)
        rvYoutubeTrending = findViewById(R.id.rvYoutubeTrending)
        homeLiveSection = findViewById(R.id.homeLiveSection)
        tvHomeLiveHeader = findViewById(R.id.tvHomeLiveHeader)
        btnHomeSeeAllLive = findViewById(R.id.btnHomeSeeAllLive)
        rvHomeLiveChannels = findViewById(R.id.rvHomeLiveChannels)
        recentAppsSection = findViewById(R.id.recentAppsSection)
        rvRecentApps = findViewById(R.id.rvRecentApps)
        rvAllRow = findViewById(R.id.rvAllRow)

        tvCinemaTitle = findViewById(R.id.tvCinemaTitle)
        tvCinemaSub = findViewById(R.id.tvCinemaSub)
        rvCinemaVideos = findViewById(R.id.rvCinemaVideos)
        rvCinemaApps = findViewById(R.id.rvCinemaApps)

        tvLiveTabTitle = findViewById(R.id.tvLiveTabTitle)
        btnLiveAddM3u = findViewById(R.id.btnLiveAddM3u)
        btnLiveRefreshM3u = findViewById(R.id.btnLiveRefreshM3u)
        btnLiveChoosePlayer = findViewById(R.id.btnLiveChoosePlayer)
        liveCategoryBar = findViewById(R.id.liveCategoryBar)
        tvLiveChannelsSubtitle = findViewById(R.id.tvLiveChannelsSubtitle)
        rvLiveChannelsGrid = findViewById(R.id.rvLiveChannelsGrid)
        rvLiveApps = findViewById(R.id.rvLiveApps)

        tvAppsTitle = findViewById(R.id.tvAppsTitle)
        btnFilterAll = findViewById(R.id.btnFilterAll)
        btnFilterTv = findViewById(R.id.btnFilterTv)
        btnFilterSideload = findViewById(R.id.btnFilterSideload)
        rvAllGrid = findViewById(R.id.rvAllGrid)
        tvDeviceHealth = findViewById(R.id.tvDeviceHealth)
        tvFavMoviesHeader = findViewById(R.id.tvFavMoviesHeader)
        rvLibraryFavMovies = findViewById(R.id.rvLibraryFavMovies)
        tvFavChannelsHeader = findViewById(R.id.tvFavChannelsHeader)
        rvLibraryFavChannels = findViewById(R.id.rvLibraryFavChannels)
        rvLibraryFavorites = findViewById(R.id.rvLibraryFavorites)
    }

    private fun setupAdapters() {
        val appClick: (AppItem) -> Unit = { launchAppWithLockCheck(it) }
        val appLongClick: (AppItem) -> Unit = { showAppOptionsDialog(it) }
        val chClick: (LiveChannel) -> Unit = { playLiveChannel(it, null) }
        val chLongClick: (LiveChannel) -> Unit = { showChannelOptionsDialog(it) }
        val ytClick: (YouTubeVideo) -> Unit = { video ->
            YouTubeRepository.openYouTubeVideo(this, prefs, video)
            refreshContinueWatchingAsync()
        }

        pinnedAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        recentAppsAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        allRowAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        cinemaAppsAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        liveAppsAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        allGridAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        libraryFavAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)
        searchAppsAdapter = AppAdapter(packageManager, prefs, appClick, appLongClick)

        continueAdapter = ContinueWatchingAdapter(prefs, { handleContinueWatchingClick(it) }) { u, r -> previewDynamicBackdrop(u, r) }
        val mbClick: (MovieBoxItem) -> Unit = { item ->
            MovieBoxEngine.openInMovieBox(this, prefs, item, allInstalledApps)
            refreshContinueWatchingAsync()
            rebuildHeroSlides()
        }
        val mbLongClick: (MovieBoxItem) -> Unit = { item -> toggleFavoriteMovie(item) }
        movieBoxAdapter = MovieBoxAdapter(prefs, mbClick, mbLongClick) { u, r -> previewDynamicBackdrop(u, r) }
        libraryFavMoviesAdapter = MovieBoxAdapter(prefs, mbClick, mbLongClick)
        ytTrendingAdapter = YouTubeAdapter(prefs, ytClick) { u, r -> previewDynamicBackdrop(u, r) }
        cinemaVideosAdapter = YouTubeAdapter(prefs, ytClick)
        searchYtAdapter = YouTubeAdapter(prefs, ytClick)

        homeChannelsAdapter = ChannelAdapter(prefs, chClick, chLongClick)
        liveChannelsAdapter = ChannelAdapter(prefs, chClick, chLongClick)
        libraryFavChannelsAdapter = ChannelAdapter(prefs, chClick, chLongClick)
        searchChannelsAdapter = ChannelAdapter(prefs, chClick, chLongClick)

        rvPinnedApps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvPinnedApps.adapter = pinnedAdapter

        rvContinueWatching.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvContinueWatching.adapter = continueAdapter

        rvMovieBoxRecs.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvMovieBoxRecs.adapter = movieBoxAdapter

        rvYoutubeTrending.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvYoutubeTrending.adapter = ytTrendingAdapter

        rvHomeLiveChannels.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvHomeLiveChannels.adapter = homeChannelsAdapter

        rvRecentApps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvRecentApps.setHasFixedSize(true)
        rvRecentApps.adapter = recentAppsAdapter

        rvLibraryFavMovies.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvLibraryFavMovies.setHasFixedSize(true)
        rvLibraryFavMovies.adapter = libraryFavMoviesAdapter

        val appPool = RecyclerView.RecycledViewPool()
        val posterPool = RecyclerView.RecycledViewPool()
        listOf(rvPinnedApps, rvRecentApps, rvAllRow).forEach {
            it.setRecycledViewPool(appPool)
            it.itemAnimator = null
            it.isNestedScrollingEnabled = false
            it.overScrollMode = View.OVER_SCROLL_NEVER
        }
        listOf(rvContinueWatching, rvMovieBoxRecs, rvYoutubeTrending).forEach {
            it.setRecycledViewPool(posterPool)
            it.itemAnimator = null
            it.isNestedScrollingEnabled = false
            it.overScrollMode = View.OVER_SCROLL_NEVER
        }
        rvHomeLiveChannels.itemAnimator = null
        rvHomeLiveChannels.isNestedScrollingEnabled = false
        rvHomeLiveChannels.overScrollMode = View.OVER_SCROLL_NEVER
        rvPinnedApps.setHasFixedSize(true)
        rvPinnedApps.setItemViewCacheSize(8)
        rvMovieBoxRecs.setItemViewCacheSize(8)
        rvYoutubeTrending.setItemViewCacheSize(8)
        rvContinueWatching.setItemViewCacheSize(8)
        rvContinueWatching.setHasFixedSize(true)
        rvMovieBoxRecs.setHasFixedSize(true)
        rvYoutubeTrending.setHasFixedSize(true)
        rvAllRow.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvAllRow.setHasFixedSize(true)
        rvAllRow.adapter = allRowAdapter

        rvCinemaVideos.layoutManager = GridLayoutManager(this, 3)
        rvCinemaVideos.adapter = cinemaVideosAdapter

        rvCinemaApps.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvCinemaApps.adapter = cinemaAppsAdapter

        rvSearchYoutube.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvSearchYoutube.adapter = searchYtAdapter

        val appCols = prefs.gridColumns.coerceIn(4, 6)
        val chCols = (appCols - 1).coerceIn(3, 4)

        rvLiveChannelsGrid.layoutManager = GridLayoutManager(this, chCols)
        rvLiveChannelsGrid.adapter = liveChannelsAdapter

        rvLiveApps.layoutManager = GridLayoutManager(this, appCols)
        rvLiveApps.adapter = liveAppsAdapter

        rvAllGrid.layoutManager = GridLayoutManager(this, appCols)
        rvAllGrid.adapter = allGridAdapter

        rvLibraryFavChannels.layoutManager = GridLayoutManager(this, chCols)
        rvLibraryFavChannels.adapter = libraryFavChannelsAdapter

        rvLibraryFavorites.layoutManager = GridLayoutManager(this, appCols)
        rvLibraryFavorites.adapter = libraryFavAdapter

        rvSearchChannels.layoutManager = GridLayoutManager(this, chCols)
        rvSearchChannels.adapter = searchChannelsAdapter

        rvSearchResults.layoutManager = GridLayoutManager(this, appCols)
        rvSearchResults.adapter = searchAppsAdapter
    }

    private fun setupListeners() {
        val darkText = Color.parseColor("#090D16")
        val whiteText = Color.WHITE

        val topTabs = listOf(tabHome, tabMovies, tabSeries, tabLive, tabApps, tabLibrary)
        topTabs.forEachIndexed { idx, tv ->
            tv.setOnClickListener { selectTab(idx) }
            tv.setOnFocusChangeListener { v, hasFocus ->
                val t = v as TextView
                t.setTextColor(if (hasFocus || t.isSelected) darkText else whiteText)
                Animation4D.apply4dFocus(v, hasFocus, prefs.isUltraLiteMode || !prefs.enable4dAnimations, 1.07f)
            }
        }

        // Left 3D Sidebar (including direct Real Android TV System Settings!)
        sideHome.setOnClickListener { selectTab(0) }
        sideMovies.setOnClickListener { selectTab(1) }
        sideSeries.setOnClickListener { selectTab(2) }
        sideLive.setOnClickListener { selectTab(3) }
        sideApps.setOnClickListener { selectTab(4) }
        sideRealTvSettings.setOnClickListener { openSystemAction(Settings.ACTION_SETTINGS) }
        sideSettings.setOnClickListener { showLauncherSettingsDialog() }

        listOf(sideHome, sideMovies, sideSeries, sideLive, sideApps, sideRealTvSettings, sideSettings).forEach { side ->
            side.setOnFocusChangeListener { v, hasFocus ->
                Animation4D.apply4dFocus(v, hasFocus, prefs.isUltraLiteMode || !prefs.enable4dAnimations, 1.06f)
            }
        }

        // Hero buttons
        btnHeroPlay.setOnClickListener { executeHeroPrimaryAction() }
        btnHeroPlay.setOnFocusChangeListener { v, hasFocus ->
            (v as TextView).setTextColor(if (hasFocus) whiteText else darkText)
            Animation4D.apply4dFocus(v, hasFocus, prefs.isUltraLiteMode || !prefs.enable4dAnimations, 1.09f)
        }

        btnHeroNext.setOnClickListener {
            if (heroSlides.isNotEmpty()) {
                heroSlideIndex = (heroSlideIndex + 1) % heroSlides.size
                renderHeroSlide()
            }
        }
        btnHeroNext.setOnFocusChangeListener { v, hasFocus ->
            (v as TextView).setTextColor(if (hasFocus) darkText else whiteText)
            Animation4D.apply4dFocus(v, hasFocus, prefs.isUltraLiteMode || !prefs.enable4dAnimations, 1.08f)
        }

        // Top utilities
        btnSearch.setOnClickListener { toggleSearch(true) }
        btnVoiceSearch.setOnClickListener { startVoiceSearch() }
        btnCloseSearch.setOnClickListener { toggleSearch(false) }
        btnRamBoost.setOnClickListener { boostRamNow() }
        btnTopTvSettings.setOnClickListener { openSystemAction(Settings.ACTION_SETTINGS) }
        btnSettings.setOnClickListener { showLauncherSettingsDialog() }
        btnProfile.setOnClickListener { showLauncherSettingsDialog() }
        btnNetwork.setOnClickListener { showNetworkManagerDialog() }
        btnClock.setOnClickListener { startActivity(Intent(this, AmbientActivity::class.java)) }

        listOf(btnSearch, btnVoiceSearch, btnRamBoost, btnTopTvSettings, btnSettings, btnProfile, btnNetwork, btnClock).forEach { util ->
            util.setOnFocusChangeListener { v, hasFocus ->
                Animation4D.apply4dFocus(v, hasFocus, prefs.isUltraLiteMode || !prefs.enable4dAnimations, 1.12f)
            }
        }

        btnSyncWatchNext.setOnClickListener { showWatchNextSyncDialog() }
        btnOpenMovieBoxApp.setOnClickListener { openMovieBoxDirect() }
        btnRefreshYt.setOnClickListener {
            Toast.makeText(this, "Refreshing YouTube Best Videos...", Toast.LENGTH_SHORT).show()
            fetchLiveYouTubeAsync()
        }
        btnHomeSeeAllLive.setOnClickListener { selectTab(3) }
        btnLiveAddM3u.setOnClickListener { showM3uSetupDialog() }
        btnLiveRefreshM3u.setOnClickListener { reloadM3uFromSavedUrl() }
        btnLiveChoosePlayer.setOnClickListener { showPreferredPlayerDialog() }

        val filters = listOf(btnFilterAll, btnFilterTv, btnFilterSideload)
        filters.forEachIndexed { idx, btn ->
            btn.setOnClickListener {
                currentAppFilter = idx
                updateFilterSelection()
                refreshAppsGrid()
            }
            btn.setOnFocusChangeListener { v, hasFocus ->
                (v as TextView).setTextColor(if (hasFocus || v.isSelected) darkText else whiteText)
            }
        }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                performSearch(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    // ==================== HERO CAROUSEL ENGINE (LAST IPTV CHANNEL AT #1!) ====================
    private fun rebuildHeroSlides() {
        val slides = mutableListOf<HeroSlide>()

        // Priority #1: Last Watched RAM PLAYER IPTV Channel right at the top!
        val lastCh = prefs.getIptvHistory().firstOrNull()
        val detectedIptv = prefs.getDetectedIptvMedia()
        if (lastCh != null) {
            slides.add(
                HeroSlide(
                    badge = "📡 RESUME LAST IPTV CHANNEL",
                    title = lastCh.name.uppercase(Locale.getDefault()),
                    subtitle = "Click Play to resume ${lastCh.name} instantly in RAM PLAYER IPTV (${lastCh.group}).",
                    ctaText = "▶  Play ${lastCh.name}",
                    backdropResId = R.drawable.hero_sports_4k,
                    actionType = HeroSlide.ACTION_RESUME_IPTV,
                    targetId = lastCh.streamUrl
                )
            )
        } else if (detectedIptv != null) {
            slides.add(
                HeroSlide(
                    badge = "📡 LAST WATCHED IN RAM PLAYER",
                    title = detectedIptv.first.uppercase(Locale.getDefault()),
                    subtitle = "Click Play to jump right back into RAM PLAYER IPTV.",
                    ctaText = "▶  Resume RAM PLAYER",
                    backdropResId = R.drawable.hero_sports_4k,
                    actionType = HeroSlide.ACTION_OPEN_LIVE_TAB
                )
            )
        } else {
            slides.add(
                HeroSlide(
                    badge = "📡 RAM PLAYER IPTV • LIVE TV",
                    title = "RAM PLAYER LIVE TV",
                    subtitle = "Launch your RAM PLAYER IPTV app or play M3U channels in blazing HD & 4K.",
                    ctaText = "▶  Open RAM PLAYER",
                    backdropResId = R.drawable.hero_sports_4k,
                    actionType = HeroSlide.ACTION_OPEN_LIVE_TAB
                )
            )
        }

        // Priority #2: Last Watched MovieBox Movie/Series!
        val lastMb = prefs.getMovieBoxHistory().firstOrNull()
        val detMb = prefs.getDetectedMovieBoxMedia()
        if (lastMb != null) {
            slides.add(
                HeroSlide(
                    badge = "🎬 CONTINUE MOVIEBOX",
                    title = lastMb.title.uppercase(Locale.getDefault()),
                    subtitle = "Resume where you left off in MovieBox • ${lastMb.meta}",
                    ctaText = "▶  Resume in MovieBox",
                    backdropResId = lastMb.posterResId,
                    backdropUrl = lastMb.posterUrl,
                    actionType = HeroSlide.ACTION_OPEN_MOVIEBOX,
                    targetId = lastMb.title
                )
            )
        } else if (detMb != null) {
            slides.add(
                HeroSlide(
                    badge = "🎬 LAST ON MOVIEBOX",
                    title = detMb.first.uppercase(Locale.getDefault()),
                    subtitle = "Click Play to resume your last movie directly in MovieBox.",
                    ctaText = "▶  Resume MovieBox",
                    backdropResId = R.drawable.hero_superhero_4k,
                    actionType = HeroSlide.ACTION_OPEN_MOVIEBOX,
                    targetId = detMb.first
                )
            )
        }

        // Priority #3: Last Watched YouTube Video
        val lastYt = prefs.getYouTubeHistory().firstOrNull()
        if (lastYt != null) {
            slides.add(
                HeroSlide(
                    badge = "▶ CONTINUE WATCHING ON YOUTUBE",
                    title = lastYt.title,
                    subtitle = "Pick up right where you left off on YouTube • ${lastYt.channelName}",
                    ctaText = "▶  Play on YouTube",
                    backdropResId = R.drawable.hero_action_4k,
                    backdropUrl = lastYt.thumbUrl,
                    actionType = HeroSlide.ACTION_RESUME_YOUTUBE,
                    targetId = lastYt.videoId
                )
            )
        }

        slides.add(
            HeroSlide(
                badge = "🔥 NEXT-GEN 4K ACTION SPOTLIGHT",
                title = "CINEMA ACTION 4K",
                subtitle = "High-octane action blockbusters, trending YouTube 4K trailers & instant IPTV streaming.",
                ctaText = "▶  Play Trailer",
                backdropResId = R.drawable.hero_horizon_4k,
                actionType = HeroSlide.ACTION_RESUME_YOUTUBE,
                targetId = "COv52Qyctws"
            )
        )
        slides.add(
            HeroSlide(
                badge = "🏎️ NEON VELOCITY 4K IMAX",
                title = "CYBER DRIFT 2099",
                subtitle = "High-speed neon cinema, 60FPS Ultra-Smooth TV engine & instant streaming.",
                ctaText = "▶  Watch 4K",
                backdropResId = R.drawable.hero_cyberpunk_4k,
                actionType = HeroSlide.ACTION_RESUME_YOUTUBE,
                targetId = "LXb3EKWsInQ"
            )
        )
        slides.add(
            HeroSlide(
                badge = "🌌 COSMIC PORTAL 4K HDR",
                title = "STARLIGHT HORIZON",
                subtitle = "Step into deep-space 4K HDR worlds on YouTube TV & MovieBox.",
                ctaText = "▶  Watch 4K HDR",
                backdropResId = R.drawable.hero_cosmic_4k,
                actionType = HeroSlide.ACTION_RESUME_YOUTUBE,
                targetId = "d9MyW72ELq0"
            )
        )
        slides.add(
            HeroSlide(
                badge = "👑 ROYAL EPIC CINEMA",
                title = "GOLDEN EMPIRE",
                subtitle = "Blockbuster Bollywood & historical epics on MovieBox and Live TV.",
                ctaText = "▶  Open MovieBox",
                backdropResId = R.drawable.hero_palace_4k,
                actionType = HeroSlide.ACTION_OPEN_MOVIEBOX,
                targetId = "RRR (Rise Roar Revolt)"
            )
        )
        slides.add(
            HeroSlide(
                badge = "🌌 ULTRA 4K SCI-FI EXPERIENCE",
                title = "NEBULA HORIZON",
                subtitle = "Immerse yourself in 4K 60fps HDR worlds on YouTube TV and your favorite streaming apps.",
                ctaText = "▶  Watch 4K HDR",
                backdropResId = R.drawable.hero_scifi_4k,
                actionType = HeroSlide.ACTION_RESUME_YOUTUBE,
                targetId = "d9MyW72ELq0"
            )
        )
        slides.add(
            HeroSlide(
                badge = "🐉 EPIC FANTASY & SERIES",
                title = "KINGDOM OF FIRE",
                subtitle = "Explore blockbuster series, epic sagas, and curated YouTube trailers in Extreme 3D UI.",
                ctaText = "▶  Play Epic 4K",
                backdropResId = R.drawable.hero_fantasy_4k,
                actionType = HeroSlide.ACTION_RESUME_YOUTUBE,
                targetId = "f_vbAtFSEc0"
            )
        )
        slides.add(
            HeroSlide(
                badge = "✨ 3D FAMILY & KIDS ADVENTURE",
                title = "ENCHANTED WORLD",
                subtitle = "Vibrant 3D animated adventures with Kids PIN lock protection built directly into UltraTV Pro.",
                ctaText = "▶  Play 4K Animated",
                backdropResId = R.drawable.hero_kids_4k,
                actionType = HeroSlide.ACTION_RESUME_YOUTUBE,
                targetId = "aqz-KE-bpKQ"
            )
        )

        heroSlides = slides
        if (heroSlideIndex >= heroSlides.size) heroSlideIndex = 0
        renderHeroSlide()
    }

    private fun previewDynamicBackdrop(url: String, fallbackResId: Int) {
        if (prefs.isUltraLiteMode || !prefs.showHeroBanner || currentTab != 0) return
        if (url.isNotBlank()) {
            MediaImageLoader.loadRemoteImage(url, ivHeroBackdrop, fallbackResId, 960)
        } else {
            MediaImageLoader.loadLocalBackdropRes(fallbackResId, ivHeroBackdrop, PerformanceTier.resolve(this, prefs))
        }
        Animation4D.animateKenBurnsHero(ivHeroBackdrop, PerformanceTier.resolve(this, prefs).enableKenBurns && prefs.enable4dAnimations)
    }

    private fun renderHeroSlide() {
        val slide = heroSlides.getOrNull(heroSlideIndex) ?: return
        tvHeroBadge.text = slide.badge
        tvHeroTitle.text = slide.title
        tvHeroSubtitle.text = slide.subtitle
        btnHeroPlay.text = slide.ctaText

        if (slide.backdropUrl.isNotBlank()) {
            MediaImageLoader.loadRemoteImage(slide.backdropUrl, ivHeroBackdrop, slide.backdropResId, 960)
        } else {
            MediaImageLoader.loadLocalBackdropRes(slide.backdropResId, ivHeroBackdrop, PerformanceTier.resolve(this, prefs))
        }
        val tier = PerformanceTier.resolve(this, prefs)
        Animation4D.animateKenBurnsHero(ivHeroBackdrop, tier.enableKenBurns && prefs.enable4dAnimations)

        heroDotsContainer.removeAllViews()
        val density = resources.displayMetrics.density
        for (i in heroSlides.indices) {
            val dot = View(this)
            val isActive = (i == heroSlideIndex)
            val w = ((if (isActive) 22 else 8) * density).toInt()
            val h = (7 * density).toInt()
            val lp = LinearLayout.LayoutParams(w, h)
            lp.marginStart = (5 * density).toInt()
            dot.layoutParams = lp
            dot.setBackgroundResource(if (isActive) R.drawable.bg_dot_active else R.drawable.bg_dot_inactive)
            heroDotsContainer.addView(dot)
        }
    }

    private fun executeHeroPrimaryAction() {
        val slide = heroSlides.getOrNull(heroSlideIndex) ?: return
        when (slide.actionType) {
            HeroSlide.ACTION_RESUME_IPTV -> {
                val ch = prefs.getIptvHistory().firstOrNull { it.streamUrl == slide.targetId }
                    ?: allLiveChannels.firstOrNull { it.streamUrl == slide.targetId }
                if (ch != null) playLiveChannel(ch, null) else openPrimaryIptvApp()
            }
            HeroSlide.ACTION_RESUME_YOUTUBE -> {
                val v = allYouTubeVideos.firstOrNull { it.videoId == slide.targetId }
                    ?: prefs.getYouTubeHistory().firstOrNull { it.videoId == slide.targetId }
                    ?: YouTubeVideo(slide.targetId, slide.title, "YouTube")
                YouTubeRepository.openYouTubeVideo(this, prefs, v)
                refreshContinueWatchingAsync()
            }
            HeroSlide.ACTION_OPEN_LIVE_TAB -> openPrimaryIptvApp()
            HeroSlide.ACTION_OPEN_MOVIEBOX -> {
                val item = allMovieBoxRecs.firstOrNull { it.title.equals(slide.targetId, true) }
                    ?: prefs.getMovieBoxHistory().firstOrNull { it.title.equals(slide.targetId, true) }
                if (item != null) MovieBoxEngine.openInMovieBox(this, prefs, item, allInstalledApps)
                else openMovieBoxDirect()
            }
            else -> selectTab(4)
        }
    }

    // ==================== YOUTUBE & CONTINUE WATCHING ====================
    private fun loadMovieBoxRecsAsync() {
        bgExecutor.execute {
            val recs = MovieBoxEngine.fetchLiveRecommendations(this)
            mainHandler.post {
                allMovieBoxRecs = recs
                movieBoxAdapter.submitList(recs)
                refreshFavoriteMovies()
            }
        }
    }

    private fun toggleFavoriteMovie(item: MovieBoxItem) {
        val favs = prefs.getFavoriteMovieTitles()
        val added = if (item.title in favs) { favs.remove(item.title); false } else { favs.add(item.title); true }
        prefs.saveFavoriteMovieTitles(favs)
        movieBoxAdapter.notifyDataSetChanged()
        refreshFavoriteMovies()
        Toast.makeText(this, if (added) "Added ★ ${item.title} to Favorite Movies" else "Removed from Favorite Movies", Toast.LENGTH_SHORT).show()
    }

    private fun refreshFavoriteMovies() {
        val favSet = prefs.getFavoriteMovieTitles()
        val favList = (allMovieBoxRecs + prefs.getMovieBoxHistory()).distinctBy { it.title.lowercase() }.filter { it.title in favSet }
        if (favList.isEmpty()) {
            tvFavMoviesHeader.visibility = View.GONE
            rvLibraryFavMovies.visibility = View.GONE
        } else {
            tvFavMoviesHeader.visibility = View.VISIBLE
            rvLibraryFavMovies.visibility = View.VISIBLE
            libraryFavMoviesAdapter.submitList(favList)
        }
    }

    private fun openMovieBoxDirect() {
        val mbApp = MovieBoxEngine.findMovieBoxPackage(allInstalledApps)
        if (mbApp != null) {
            launchAppWithLockCheck(mbApp)
        } else {
            Toast.makeText(this, "MovieBox app not found on TV — showing 4K trailers", Toast.LENGTH_SHORT).show()
            selectTab(1)
        }
    }

    private fun fetchWeatherAsync() {
        bgExecutor.execute {
            val w = WeatherRepository.fetchWeatherSummary()
            if (!w.isNullOrBlank()) {
                mainHandler.post {
                    tvWeather.text = w
                    tvWeather.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun fetchLiveYouTubeAsync() {
        bgExecutor.execute {
            val videos = YouTubeRepository.fetchLiveTrendingVideos()
            mainHandler.post {
                allYouTubeVideos = videos
                ytTrendingAdapter.submitList(videos)
                refreshCinemaTabContent()
            }
        }
    }

    private fun refreshContinueWatchingAsync() {
        bgExecutor.execute {
            val cwList = ContinueWatchingEngine.buildContinueWatchingList(this, prefs, allInstalledApps)
            mainHandler.post {
                if (cwList.isEmpty()) {
                    continueSection.visibility = View.GONE
                } else {
                    continueSection.visibility = View.VISIBLE
                    continueAdapter.submitList(cwList)
                }
            }
        }
    }

    private fun handleContinueWatchingClick(item: ContinueWatchingItem) {
        when (item.type) {
            ContinueWatchingItem.TYPE_YOUTUBE -> {
                val vid = YouTubeVideo(
                    videoId = item.videoId,
                    title = item.title,
                    channelName = item.subtitle.removePrefix("Continue on YouTube • ")
                )
                YouTubeRepository.openYouTubeVideo(this, prefs, vid)
                refreshContinueWatchingAsync()
            }
            ContinueWatchingItem.TYPE_YOUTUBE_SEARCH -> {
                YouTubeRepository.openYouTubeSearch(this, item.title)
            }
            ContinueWatchingItem.TYPE_IPTV_CHANNEL -> {
                val ch = LiveChannel(
                    id = item.id,
                    name = item.title,
                    group = "RAM PLAYER IPTV",
                    logoUrl = item.thumbUrl,
                    streamUrl = item.streamUrl,
                    userAgent = item.streamUserAgent,
                    referrer = item.streamReferrer
                )
                playLiveChannel(ch, item.packageName.ifBlank { null })
            }
            ContinueWatchingItem.TYPE_MOVIEBOX -> {
                val mb = allMovieBoxRecs.firstOrNull { it.title.equals(item.title, true) }
                    ?: prefs.getMovieBoxHistory().firstOrNull { it.title.equals(item.title, true) }
                    ?: MovieBoxItem(item.id, item.title, item.subtitle, "★ HD", "Movies", item.fallbackResId, item.thumbUrl, deepLinkUri = item.deepLinkUri)
                MovieBoxEngine.openInMovieBox(this, prefs, mb, allInstalledApps)
                refreshContinueWatchingAsync()
            }
            ContinueWatchingItem.TYPE_IPTV_APP -> {
                openPrimaryIptvApp()
            }
            ContinueWatchingItem.TYPE_WATCH_NEXT -> {
                try {
                    val intent = Intent.parseUri(item.deepLinkUri, Intent.URI_INTENT_SCHEME).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    startActivity(intent)
                } catch (_: Throwable) {
                    if (item.packageName.isNotBlank()) {
                        allInstalledApps.firstOrNull { it.packageName == item.packageName }?.let {
                            launchAppWithLockCheck(it)
                        }
                    }
                }
            }
        }
    }

    private fun showWatchNextSyncDialog() {
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Auto-Sync YouTube & RAM PLAYER IPTV")
            .setMessage(
                "1. Every YouTube video & RAM PLAYER IPTV channel you play from UltraTV Pro is automatically saved to Home & Continue Watching.\n\n" +
                "2. Turn ON 'UltraTV Continue Watching Sync' in Notification Access so even videos played directly inside YouTube TV or RAM PLAYER before turning off your TV appear automatically on Home!"
            )
            .setPositiveButton("Enable Auto-Sync") { _, _ ->
                openSystemAction("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
            }
            .setNeutralButton("Refresh Now") { _, _ ->
                refreshContinueWatchingAsync()
                rebuildHeroSlides()
                Toast.makeText(this, "Continue Watching synced!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    // ==================== 3D WI-FI & ETHERNET NETWORK MANAGER ====================
    private fun showNetworkManagerDialog() {
        val (netType, isOnline) = getNetworkStatus()
        val ip = getLocalIpAddress()
        val statusText = if (isOnline) "Connected via $netType • IP: $ip" else "Disconnected (Offline)"

        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_settings_3d, null)
        val rv = dialogView.findViewById<RecyclerView>(R.id.rvSettings3d)
        val btnClose = dialogView.findViewById<TextView>(R.id.btnCloseSettings3d)
        val dialog = AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setView(dialogView)
            .create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val items = listOf(
            Setting3DItem(1, if (netType == "Ethernet") R.drawable.ic_3d_ethernet else R.drawable.ic_3d_wifi,
                "Network Status: $netType", statusText, if (isOnline) "ONLINE" else "OFFLINE"),
            Setting3DItem(2, R.drawable.ic_3d_wifi,
                "Wi-Fi Settings", "Connect or switch Wi-Fi networks on your TV", "OPEN"),
            Setting3DItem(3, R.drawable.ic_3d_ethernet,
                "Ethernet & Network Settings", "Configure LAN cable, Static IP & Proxy safely", "OPEN"),
            Setting3DItem(4, R.drawable.ic_3d_tv_settings,
                "Full Android TV System Settings", "Open real TV settings (Display, Sound, HDMI, Storage)", "TV OS")
        )

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = Settings3DAdapter(items) { item ->
            dialog.dismiss()
            when (item.id) {
                2 -> openSystemAction(Settings.ACTION_WIFI_SETTINGS)
                3 -> openSystemAction(Settings.ACTION_WIRELESS_SETTINGS)
                4 -> openSystemAction(Settings.ACTION_SETTINGS)
                else -> updateClockAndStatus()
            }
        }
        btnClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun getNetworkStatus(): Pair<String, Boolean> {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val net = cm.activeNetwork ?: return Pair("Offline", false)
            val caps = cm.getNetworkCapabilities(net) ?: return Pair("Offline", false)
            val hasNet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            if (!hasNet) return Pair("Offline", false)
            return when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> Pair("Ethernet", true)
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> Pair("WiFi", true)
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> Pair("Mobile", true)
                else -> Pair("Online", true)
            }
        } else {
            @Suppress("DEPRECATION")
            val info = cm.activeNetworkInfo ?: return Pair("Offline", false)
            @Suppress("DEPRECATION")
            if (!info.isConnected) return Pair("Offline", false)
            @Suppress("DEPRECATION")
            return when (info.type) {
                ConnectivityManager.TYPE_ETHERNET -> Pair("Ethernet", true)
                ConnectivityManager.TYPE_WIFI -> Pair("WiFi", true)
                else -> Pair("Online", true)
            }
        }
    }

    private fun getLocalIpAddress(): String {
        return try {
            val en = NetworkInterface.getNetworkInterfaces()
            while (en.hasMoreElements()) {
                val intf = en.nextElement()
                val addrs = intf.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return addr.hostAddress ?: "Ready"
                    }
                }
            }
            "Ready"
        } catch (_: Throwable) { "Ready" }
    }

    // ==================== 3D GLASSMORPHIC CUSTOMIZER (ALL 3D ICONS!) ====================
    private fun showLauncherSettingsDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_settings_3d, null)
        val rv = dialogView.findViewById<RecyclerView>(R.id.rvSettings3d)
        val btnClose = dialogView.findViewById<TextView>(R.id.btnCloseSettings3d)

        val dialog = AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setView(dialogView)
            .create()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val themeName = themes[prefs.themeIndex.coerceIn(0, themes.lastIndex)].first
        val items = listOf(
            Setting3DItem(0, R.drawable.ic_3d_default_home,
                "Default Home Launcher Setup Wizard",
                if (LauncherHomeManager.isDefaultHomeLauncher(this)) "Active Default Home • Tap to manage or restore original"
                else "Not Default (Current: ${LauncherHomeManager.getCurrentDefaultHomePackage(this)})",
                if (LauncherHomeManager.isDefaultHomeLauncher(this)) "ACTIVE" else "SET HOME"),
            Setting3DItem(18, R.drawable.ic_3d_boost,
                "Performance Tier (512MB / 1GB / 2GB / 3GB+)",
                "Current: ${PerformanceTier.resolve(this@MainActivity, prefs).label}",
                "TIER"),
            Setting3DItem(19, R.drawable.ic_3d_library,
                "Backup & Restore Settings",
                "Save or restore pinned apps, favorites, M3U & speed-dials",
                "BACKUP"),
            Setting3DItem(17, R.drawable.ic_3d_rocket,
                "Optional ADB TV Helper & Boot Diagnostics",
                "Last Boot: ${prefs.getBootDiagnosticSummary()}",
                "DIAG"),
            Setting3DItem(1, R.drawable.ic_3d_tv_settings,
                "Real Android TV System Settings", "Display, Sound, HDMI, Bluetooth, Storage & Device Prefs", "OPEN TV"),
            Setting3DItem(2, R.drawable.ic_3d_ethernet,
                "Wi-Fi & Ethernet Network Manager", "Check LAN/Wi-Fi IP and open TV Network Settings", "NETWORK"),
            Setting3DItem(3, R.drawable.ic_3d_sync,
                "Auto-Sync YouTube & RAM PLAYER", "Auto-show last YouTube video & IPTV channel on Home", "SYNC"),
            Setting3DItem(4, R.drawable.ic_3d_playlist,
                "Add / Edit Live TV M3U Playlist", "${allLiveChannels.size} channels loaded for 1-click Home playback", "M3U"),
            Setting3DItem(5, R.drawable.ic_3d_iptv,
                "Default IPTV Player (RAM PLAYER)", "Choose RAM PLAYER IPTV as primary stream player", "PLAYER"),
            Setting3DItem(6, R.drawable.ic_3d_sparkles,
                "4D/3D Focus & Ken Burns Animations", "Smooth bouncy 3D tilt, lift & cinema backdrop motion", if (prefs.enable4dAnimations) "ON" else "OFF"),
            Setting3DItem(7, R.drawable.ic_3d_theme,
                "3D Theme Backdrop", themeName, "THEME"),
            Setting3DItem(8, R.drawable.ic_3d_rocket,
                "TV Boot Startup Mode", "Instant Home / Auto-Launch RAM PLAYER / DTH Last Channel", "BOOT"),
            Setting3DItem(9, R.drawable.ic_3d_boost,
                "Ultra-Lite 512MB RAM Mode", "Extra-light mode for 512MB TVs (off recommended on 2GB)", if (prefs.isUltraLiteMode) "ON" else "OFF"),
            Setting3DItem(10, R.drawable.ic_3d_movies,
                "Cinematic 4K Hero Banner", "Show or hide top full-bleed 4K cinema spotlight", if (prefs.showHeroBanner) "ON" else "OFF"),
            Setting3DItem(15, R.drawable.ic_3d_moviebox,
                "MovieBox Recommendations Row", "Show MovieBox movie & series recommendations on Home", if (prefs.showMovieBoxRow) "ON" else "OFF"),
            Setting3DItem(16, R.drawable.ic_3d_sidebar,
                "Left 3D Floating Sidebar", "Toggle between 3D Sidebar Mode and Full-Screen Cinema Mode", if (prefs.showLeftSidebar) "ON" else "OFF"),
            Setting3DItem(11, R.drawable.ic_3d_clock,
                "Clock Format", "Switch between 12-Hour AM/PM and 24-Hour clock", if (prefs.is24HourClock) "24H" else "12H"),
            Setting3DItem(12, R.drawable.ic_3d_apps,
                "Grid Columns", "Number of app cards per row in Apps & Live TV grids", "${prefs.gridColumns} COLS"),
            Setting3DItem(13, R.drawable.ic_3d_lock,
                "Kids Lock PIN", "Protect apps with 4-digit PIN (Current: ${prefs.kidsPin})", "PIN"),
            Setting3DItem(14, R.drawable.ic_3d_eye,
                "Unhide Hidden Apps", "${prefs.getHiddenPackages().size} hidden apps", "MANAGE")
        )

        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = Settings3DAdapter(items) { item ->
            dialog.dismiss()
            when (item.id) {
                0 -> LauncherHomeManager.showSetupWizard(this, allInstalledApps) { launchAppDirect(it) }
                17 -> LauncherHomeManager.showAdbTvGuide(this, allInstalledApps) { launchAppDirect(it) }
                18 -> showPerformanceTierDialog()
                19 -> showBackupRestoreDialog()
                1 -> openSystemAction(Settings.ACTION_SETTINGS)
                2 -> showNetworkManagerDialog()
                3 -> showWatchNextSyncDialog()
                4 -> showM3uSetupDialog()
                5 -> showPreferredPlayerDialog()
                6 -> {
                    prefs.enable4dAnimations = !prefs.enable4dAnimations
                    Toast.makeText(this, "4D Animations: ${if (prefs.enable4dAnimations) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
                }
                7 -> showThemePicker()
                8 -> showBootModeDialog()
                9 -> {
                    prefs.isUltraLiteMode = !prefs.isUltraLiteMode
                    applyUserPreferences()
                    selectTab(currentTab)
                }
                10 -> {
                    prefs.showHeroBanner = !prefs.showHeroBanner
                    selectTab(currentTab)
                }
                11 -> {
                    prefs.is24HourClock = !prefs.is24HourClock
                    updateClockAndStatus()
                }
                12 -> {
                    prefs.gridColumns = when (prefs.gridColumns) { 4 -> 5; 5 -> 6; else -> 4 }
                    applyUserPreferences()
                }
                13 -> showChangePinDialog()
                14 -> showUnhideAppsDialog()
                15 -> {
                    prefs.showMovieBoxRow = !prefs.showMovieBoxRow
                    applyUserPreferences()
                }
                16 -> {
                    prefs.showLeftSidebar = !prefs.showLeftSidebar
                    applyUserPreferences()
                }
            }
        }
        btnClose.setOnClickListener { dialog.dismiss() }
        dialog.show()
    }

    private fun promptSetDefaultLauncher() {
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("100% Permanent Default Home Launcher")
            .setMessage(
                "Step 1: Click 'Open Home Chooser' below and select 'UltraTV Pro 3D -> Always'.\n\n" +
                "Step 2 (If TV resets to old launcher on reboot): On Android TV / Google TV, disable the old stock launcher once using 'AtvTools' or 'ADB TV' app:\n" +
                "• pm disable-user --user 0 com.google.android.tvlauncher\n" +
                "• (or) pm disable-user --user 0 com.google.android.apps.tv.launcherx\n\n" +
                "After that, UltraTV Pro 3D boots in <1 second and the old launcher NEVER opens again!"
            )
            .setPositiveButton("Open Home Chooser") { _, _ ->
                triggerSystemHomeChooser()
            }
            .setNeutralButton("TV Home Settings") { _, _ ->
                openSystemAction(Settings.ACTION_HOME_SETTINGS)
            }
            .setNegativeButton("Close", null)
            .show()
    }


    private fun showAdbTvOldLauncherRemoverDialog() {
        val stockLaunchers = listOf(
            "com.google.android.apps.tv.launcherx",
            "com.google.android.tvlauncher",
            "com.mitv.tvhome",
            "com.tcl.cyberui",
            "com.sony.dtv.homelauncher",
            "com.amazon.tv.launcher"
        )
        val detectedPkg = stockLaunchers.firstOrNull { pkg ->
            try { packageManager.getPackageInfo(pkg, 0); true } catch (_: Throwable) { false }
        } ?: "com.google.android.tvlauncher"

        val cmd = "pm disable-user --user 0 $detectedPkg"
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.setPrimaryClip(ClipData.newPlainText("ADB Disable Stock Launcher", cmd))

        val adbApps = listOf("com.cybercat.adbappcontrol.tv", "com.cgutman.androidremotedebugger", "dev.vodik7.tvquickactions", "com.htc.atvtools")
        val installedAdb = allInstalledApps.firstOrNull { app ->
            app.packageName in adbApps || app.label.contains("adb", true) || app.label.contains("atvtools", true)
        }

        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("ADB TV — Disable Old Launcher Forever")
            .setMessage(
                "Detected Stock Launcher: $detectedPkg\n\n" +
                "Command Copied to Clipboard:\n$cmd\n\n" +
                "Steps (1-time only, 30 seconds):\n" +
                "1. Open 'Developer Options' and turn ON USB / Network Debugging.\n" +
                "2. Open 'ADB TV' (or AtvTools on phone) and disable '$detectedPkg' (or paste the copied command).\n\n" +
                "After this, the old launcher NEVER opens and UltraTV Pro 3D boots in <1 second!"
            )
            .setPositiveButton(if (installedAdb != null) "Open ${installedAdb.label}" else "Install ADB TV") { _, _ ->
                if (installedAdb != null) {
                    launchAppDirect(installedAdb)
                } else {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.cybercat.adbappcontrol.tv")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Throwable) {
                        openSystemAction(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
                    }
                }
            }
            .setNeutralButton("Developer Options") { _, _ ->
                openSystemAction(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            }
            .setNegativeButton("Home Chooser") { _, _ ->
                triggerSystemHomeChooser()
            }
            .show()
    }

    private fun triggerSystemHomeChooser() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    return
                }
            }
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (_: Throwable) {
            try {
                val selector = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(Intent.createChooser(selector, "Select UltraTV Pro 3D -> Always"))
            } catch (_: Throwable) {
                openSystemAction(Settings.ACTION_SETTINGS)
            }
        }
    }

    // ==================== M3U LIVE TV ENGINE ====================
    private fun loadCachedChannelsAsync() {
        bgExecutor.execute {
            val cached = M3uRepository.loadCachedChannels(this)
            mainHandler.post {
                allLiveChannels = cached
                rebuildLiveCategoryBar()
                refreshChannelLists()
            }
        }
    }

    private fun reloadM3uFromSavedUrl() {
        val url = prefs.m3uUrl.trim()
        if (url.isBlank()) {
            showM3uSetupDialog()
            return
        }
        Toast.makeText(this, "Updating Live TV channels...", Toast.LENGTH_SHORT).show()
        bgExecutor.execute {
            val res = M3uRepository.fetchAndCacheFromUrl(this, url)
            mainHandler.post {
                res.onSuccess { list ->
                    allLiveChannels = list
                    currentLiveGroup = "All"
                    rebuildLiveCategoryBar()
                    refreshChannelLists()
                    Toast.makeText(this, "Loaded ${list.size} Live TV channels!", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    Toast.makeText(this, "Failed to load M3U: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showM3uSetupDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/playlist.m3u OR paste #EXTM3U"
            setText(prefs.m3uUrl)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#94A3B8"))
            setPadding(32, 24, 32, 24)
            maxLines = 4
        }
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Add IPTV / Live TV M3U Playlist")
            .setMessage("Enter your M3U playlist link. Clicking any channel plays directly in RAM PLAYER IPTV and pins it at the top of Home!")
            .setView(input)
            .setPositiveButton("Load Channels") { _, _ ->
                val raw = input.text?.toString()?.trim().orEmpty()
                if (raw.isBlank()) return@setPositiveButton
                if (raw.startsWith("http://", true) || raw.startsWith("https://", true)) {
                    prefs.m3uUrl = raw
                    reloadM3uFromSavedUrl()
                } else {
                    bgExecutor.execute {
                        val parsed = M3uRepository.saveAndParseRaw(this, raw)
                        mainHandler.post {
                            allLiveChannels = parsed
                            currentLiveGroup = "All"
                            rebuildLiveCategoryBar()
                            refreshChannelLists()
                            Toast.makeText(this, "Saved ${parsed.size} channels!", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            .setNeutralButton("Clear") { _, _ ->
                prefs.m3uUrl = ""
                M3uRepository.saveAndParseRaw(this, "")
                allLiveChannels = emptyList()
                rebuildLiveCategoryBar()
                refreshChannelLists()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun rebuildLiveCategoryBar() {
        liveCategoryBar.removeAllViews()
        if (allLiveChannels.isEmpty()) return
        val groups = mutableListOf("All", "★ Favorites")
        groups.addAll(allLiveChannels.map { it.group }.distinct().take(25))
        val darkText = Color.parseColor("#090D16")
        val whiteText = Color.WHITE

        for (grp in groups) {
            val pill = TextView(this).apply {
                text = grp
                textSize = 12f
                isSelected = (grp == currentLiveGroup)
                setTextColor(if (isSelected) darkText else whiteText)
                setBackgroundResource(R.drawable.bg_top_tab_pill)
                isFocusable = true
                isClickable = true
                gravity = Gravity.CENTER
                setPadding(24, 10, 24, 10)
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.marginEnd = 10
                layoutParams = lp
                setOnFocusChangeListener { v, hasFocus ->
                    (v as TextView).setTextColor(if (hasFocus || v.isSelected) darkText else whiteText)
                }
                setOnClickListener {
                    currentLiveGroup = grp
                    rebuildLiveCategoryBar()
                    refreshChannelLists()
                }
            }
            liveCategoryBar.addView(pill)
        }
    }

    private fun refreshChannelLists() {
        val favUrls = prefs.getFavoriteChannelIds()
        val favChannels = allLiveChannels.filter { it.streamUrl in favUrls }

        if (allLiveChannels.isEmpty()) {
            homeLiveSection.visibility = View.GONE
        } else {
            homeLiveSection.visibility = View.VISIBLE
            tvHomeLiveHeader.text = "Live TV Channels (${allLiveChannels.size})"
            homeChannelsAdapter.submitList((favChannels + allLiveChannels).distinctBy { it.streamUrl }.take(24))
        }

        val filtered = when (currentLiveGroup) {
            "All" -> allLiveChannels
            "★ Favorites" -> favChannels
            else -> allLiveChannels.filter { it.group == currentLiveGroup }
        }
        tvLiveTabTitle.text = if (allLiveChannels.isEmpty()) "Live TV & RAM PLAYER Hub" else "Live TV • ${filtered.size} Channels"
        tvLiveChannelsSubtitle.text = if (allLiveChannels.isEmpty()) {
            "Click '+ Add M3U' to load your channels here & on Home Screen!"
        } else {
            "Press OK to play in RAM PLAYER IPTV • Hold OK for Favorites & Speed-Dial 1-9"
        }
        liveChannelsAdapter.submitList(filtered)

        if (favChannels.isEmpty()) {
            tvFavChannelsHeader.visibility = View.GONE
            rvLibraryFavChannels.visibility = View.GONE
        } else {
            tvFavChannelsHeader.visibility = View.VISIBLE
            rvLibraryFavChannels.visibility = View.VISIBLE
            libraryFavChannelsAdapter.submitList(favChannels)
        }
    }

    private fun playLiveChannel(ch: LiveChannel, overridePlayerPkg: String?) {
        prefs.recordIptvChannelWatch(ch)
        refreshContinueWatchingAsync()
        rebuildHeroSlides()

        val targetPkg = overridePlayerPkg ?: prefs.preferredIptvPlayer.ifBlank {
            allInstalledApps.firstOrNull { it.packageName == RAM_PLAYER_PKG }?.packageName ?: ""
        }

        val streamIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(ch.streamUrl), "video/*")
            putExtra("title", ch.name)
            putExtra("name", ch.name)
            putExtra("url", ch.streamUrl)
            if (ch.userAgent.isNotBlank()) {
                putExtra("user_agent", ch.userAgent)
                putExtra("headers", arrayOf("User-Agent", ch.userAgent))
            }
            if (ch.referrer.isNotBlank()) {
                putExtra("referer", ch.referrer)
            }
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (targetPkg.isNotBlank()) {
            streamIntent.setPackage(targetPkg)
            try {
                startActivity(streamIntent)
                return
            } catch (_: Throwable) {
                streamIntent.setPackage(null)
            }
        }
        try {
            startActivity(Intent.createChooser(streamIntent, "Play ${ch.name} with"))
        } catch (_: Throwable) {
            Toast.makeText(this, "No IPTV player found", Toast.LENGTH_LONG).show()
        }
    }

    private fun openPrimaryIptvApp() {
        val prefPkg = prefs.preferredIptvPlayer
        val target = allInstalledApps.firstOrNull { it.packageName == prefPkg }
            ?: allInstalledApps.firstOrNull { it.packageName == RAM_PLAYER_PKG }
            ?: allInstalledApps.firstOrNull { it.packageName.contains("iptv", true) }
        if (target != null) launchAppWithLockCheck(target) else selectTab(3)
    }

    private fun showChannelOptionsDialog(ch: LiveChannel) {
        val favs = prefs.getFavoriteChannelIds()
        val isFav = ch.streamUrl in favs
        val options = arrayOf(
            "Play ${ch.name}",
            "Choose Video/IPTV Player",
            if (isFav) "Remove from Favorites" else "Add to Favorites",
            "Assign Remote Speed-Dial Key (1-9)",
            "Set as Boot Auto-Play Channel (DTH Mode)"
        )
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle(ch.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> playLiveChannel(ch, null)
                    1 -> showPlayerPickerForChannel(ch)
                    2 -> {
                        if (isFav) favs.remove(ch.streamUrl) else favs.add(ch.streamUrl)
                        prefs.saveFavoriteChannelIds(favs)
                        refreshChannelLists()
                    }
                    3 -> showSpeedDialAssignDialog("ch:${ch.streamUrl}", ch.name)
                    4 -> {
                        prefs.recordIptvChannelWatch(ch)
                        prefs.bootMode = 2
                        Toast.makeText(this, "Boot DTH Mode ON: ${ch.name}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .show()
    }

    private fun showPlayerPickerForChannel(ch: LiveChannel) {
        val players = allInstalledApps.filter { it.isLiveTvCandidate }.ifEmpty { allInstalledApps }
        val names = (listOf("System Chooser") + players.map { it.label }).toTypedArray()
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Play ${ch.name} using:")
            .setItems(names) { _, which ->
                playLiveChannel(ch, if (which == 0) "" else players[which - 1].packageName)
            }
            .show()
    }

    private fun showPreferredPlayerDialog() {
        val players = allInstalledApps.filter { it.isLiveTvCandidate }.ifEmpty { allInstalledApps }
        val names = (listOf("Auto (Prefer RAM PLAYER)") + players.map { it.label }).toTypedArray()
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Default IPTV Stream Player")
            .setItems(names) { _, which ->
                if (which == 0) {
                    prefs.preferredIptvPlayer = ""
                    Toast.makeText(this, "Default player: Auto", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.preferredIptvPlayer = players[which - 1].packageName
                    Toast.makeText(this, "Default player: ${players[which - 1].label}", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    // ==================== APPS ENGINE ====================
    private fun loadAppsAsync() {
        bgExecutor.execute {
            val pm = packageManager
            val tvPackages = mutableSetOf<String>()
            val combinedMap = linkedMapOf<String, AppItem>()

            val tvIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
            for (ri in pm.queryIntentActivities(tvIntent, 0)) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == packageName) continue
                tvPackages.add(pkg)
                val label = ri.loadLabel(pm)?.toString()?.trim().orEmpty().ifEmpty { pkg }
                combinedMap[pkg] = AppItem(pkg, label, true, isLiveCandidate(pkg, label))
            }

            val stdIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(stdIntent, 0)) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == packageName) continue
                if (!combinedMap.containsKey(pkg)) {
                    val label = ri.loadLabel(pm)?.toString()?.trim().orEmpty().ifEmpty { pkg }
                    combinedMap[pkg] = AppItem(pkg, label, pkg in tvPackages, isLiveCandidate(pkg, label))
                }
            }

            val sorted = combinedMap.values.sortedWith(
                compareByDescending<AppItem> { it.packageName == RAM_PLAYER_PKG }
                    .thenByDescending { it.packageName.contains("moviebox", true) || it.label.contains("movie", true) }
                    .thenByDescending { it.packageName.contains("youtube", true) }
                    .thenByDescending { it.isLiveTvCandidate }
                    .thenByDescending { it.isTvApp }
                    .thenBy { it.label.lowercase(Locale.getDefault()) }
            )

            mainHandler.post {
                allInstalledApps = sorted
                prefs.saveCachedApps(sorted)
                if (prefs.getPinnedPackages().isEmpty() && sorted.isNotEmpty()) {
                    prefs.savePinnedPackages(sorted.take(10).map { it.packageName })
                }
                refreshUiLists()
                refreshContinueWatchingAsync()
            }
        }
    }

    private fun isLiveCandidate(pkg: String, label: String): Boolean {
        val lower = (pkg + " " + label).lowercase(Locale.getDefault())
        return liveTvKeywords.any { lower.contains(it) }
    }

    private fun refreshUiLists() {
        val hidden = prefs.getHiddenPackages()
        val visible = allInstalledApps.filter { it.packageName !in hidden }
        val mapByPkg = visible.associateBy { it.packageName }

        val pinnedList = prefs.getPinnedPackages().mapNotNull { mapByPkg[it] }.ifEmpty { visible.take(10) }
        pinnedAdapter.submitList(pinnedList)
        libraryFavAdapter.submitList(pinnedList)
        allRowAdapter.submitList(visible)
        val recentList = prefs.getRecentPackages().mapNotNull { mapByPkg[it] }
        if (recentList.isEmpty()) {
            recentAppsSection.visibility = View.GONE
        } else {
            recentAppsSection.visibility = View.VISIBLE
            recentAppsAdapter.submitList(recentList)
        }

        if (currentTab == 1 || currentTab == 2 || currentTab == 3) {
            val liveApps = visible.filter { it.isLiveTvCandidate }.ifEmpty { visible.take(10) }
            liveAppsAdapter.submitList(liveApps)
            cinemaAppsAdapter.submitList(liveApps)
        }
        if (currentTab == 4) refreshAppsGrid()
    }

    private fun refreshCinemaTabContent() {
        val videos = when (currentTab) {
            1 -> allYouTubeVideos.filter { it.category.equals("Movies", true) || it.category.equals("Trending", true) }
                .ifEmpty { allYouTubeVideos }
            2 -> allYouTubeVideos.filter { it.category.equals("Series", true) || it.category.equals("Music", true) }
                .ifEmpty { allYouTubeVideos }
            else -> allYouTubeVideos
        }
        cinemaVideosAdapter.submitList(videos)
    }

    private fun refreshAppsGrid() {
        val hidden = prefs.getHiddenPackages()
        val visible = allInstalledApps.filter { it.packageName !in hidden }
        val filtered = when (currentAppFilter) {
            1 -> visible.filter { it.isTvApp }
            2 -> visible.filter { !it.isTvApp }
            else -> visible
        }
        tvAppsTitle.text = when (currentAppFilter) {
            1 -> "TV Apps (${filtered.size})"
            2 -> "Sideloaded Apps (${filtered.size})"
            else -> "All Apps (${filtered.size})"
        }
        allGridAdapter.submitList(filtered)
    }

    private fun launchAppWithLockCheck(item: AppItem) {
        if (item.packageName in prefs.getLockedPackages()) {
            promptKidsPin("Unlock ${item.label}") { launchAppDirect(item) }
        } else {
            launchAppDirect(item)
        }
    }

    private fun launchAppDirect(item: AppItem) {
        val intent = packageManager.getLeanbackLaunchIntentForPackage(item.packageName)
            ?: packageManager.getLaunchIntentForPackage(item.packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            prefs.recordRecentPackage(item.packageName)
            try {
                startActivity(intent)
            } catch (_: Throwable) {
                Toast.makeText(this, "Cannot open ${item.label}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun promptKidsPin(title: String, onSuccess: () -> Unit) {
        val input = EditText(this).apply {
            hint = "Enter 4-digit PIN (Default: 1234)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#94A3B8"))
            setPadding(32, 24, 32, 24)
        }
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("Unlock") { _, _ ->
                if (input.text?.toString() == prefs.kidsPin) onSuccess()
                else Toast.makeText(this, "Wrong PIN!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAppOptionsDialog(item: AppItem) {
        val pinned = prefs.getPinnedPackages()
        val isPinned = item.packageName in pinned
        val locked = prefs.getLockedPackages()
        val isLocked = item.packageName in locked

        val options = mutableListOf(
            "Open ${item.label}",
            if (isPinned) "Unpin from Your Apps" else "Pin to Your Apps"
        )
        if (isPinned) {
            options.add("Move Left")
            options.add("Move Right")
        }
        options.add("Assign Remote Speed-Dial Key (1-9)")
        options.add("Set as TV Boot Auto-Launch App")
        options.add(if (isLocked) "Unlock App" else "Lock App with Kids PIN")
        options.add("Hide App")
        options.add("App Info")
        options.add("Uninstall App")

        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle(item.label)
            .setItems(options.toTypedArray()) { _, which ->
                val c = options[which]
                when {
                    c.startsWith("Open") -> launchAppWithLockCheck(item)
                    c.startsWith("Unpin") -> { pinned.remove(item.packageName); prefs.savePinnedPackages(pinned); refreshUiLists() }
                    c.startsWith("Pin") -> { pinned.add(0, item.packageName); prefs.savePinnedPackages(pinned); refreshUiLists() }
                    c == "Move Left" -> {
                        val i = pinned.indexOf(item.packageName)
                        if (i > 0) { pinned.removeAt(i); pinned.add(i - 1, item.packageName); prefs.savePinnedPackages(pinned); refreshUiLists() }
                    }
                    c == "Move Right" -> {
                        val i = pinned.indexOf(item.packageName)
                        if (i in 0 until pinned.lastIndex) { pinned.removeAt(i); pinned.add(i + 1, item.packageName); prefs.savePinnedPackages(pinned); refreshUiLists() }
                    }
                    c.startsWith("Assign") -> showSpeedDialAssignDialog("app:${item.packageName}", item.label)
                    c.startsWith("Set as TV Boot") -> {
                        prefs.autoLaunchPackage = item.packageName
                        prefs.bootMode = 1
                        Toast.makeText(this, "Boot Auto-Launch: ${item.label}", Toast.LENGTH_LONG).show()
                    }
                    c == "Unlock App" -> promptKidsPin("Remove Lock") {
                        locked.remove(item.packageName); prefs.saveLockedPackages(locked); refreshUiLists()
                    }
                    c.startsWith("Lock App") -> { locked.add(item.packageName); prefs.saveLockedPackages(locked); refreshUiLists() }
                    c == "Hide App" -> { val h = prefs.getHiddenPackages(); h.add(item.packageName); prefs.saveHiddenPackages(h); refreshUiLists() }
                    c == "App Info" -> try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${item.packageName}"))) } catch (_: Throwable) {}
                    c == "Uninstall App" -> try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${item.packageName}"))) } catch (_: Throwable) {}
                }
            }
            .show()
    }

    private fun showSpeedDialAssignDialog(target: String, label: String) {
        val keys = (1..9).map { d ->
            if (prefs.getSpeedDial(d).isBlank()) "Remote Key $d (Empty)" else "Remote Key $d (Replace)"
        }.toTypedArray()
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Speed-Dial Key for $label")
            .setItems(keys) { _, which ->
                prefs.setSpeedDial(which + 1, target)
                refreshUiLists()
                refreshChannelLists()
                Toast.makeText(this, "Press '${which + 1}' on Remote to launch $label!", Toast.LENGTH_LONG).show()
            }
            .setNeutralButton("Clear") { _, _ ->
                for (d in 1..9) if (prefs.getSpeedDial(d) == target) prefs.setSpeedDial(d, "")
                refreshUiLists()
                refreshChannelLists()
            }
            .show()
    }

    // ==================== SEARCH & VOICE ====================
    private fun startVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak app, YouTube video, or Live TV channel...")
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_VOICE_SEARCH)
        } catch (_: Throwable) {
            toggleSearch(true)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VOICE_SEARCH && resultCode == Activity.RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                toggleSearch(true)
                etSearch.setText(spoken)
                etSearch.setSelection(spoken.length)
                performSearch(spoken)
            }
        }
    }

    private fun toggleSearch(show: Boolean) {
        if (show) {
            searchBarContainer.visibility = View.VISIBLE
            heroBackdropLayer.visibility = View.GONE
            viewHome.visibility = View.GONE
            viewCinema.visibility = View.GONE
            viewLive.visibility = View.GONE
            viewApps.visibility = View.GONE
            viewLibrary.visibility = View.GONE
            viewSearchResults.visibility = View.VISIBLE
            etSearch.setText("")
            etSearch.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT)
            performSearch("")
        } else {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(etSearch.windowToken, 0)
            searchBarContainer.visibility = View.GONE
            viewSearchResults.visibility = View.GONE
            selectTab(currentTab)
        }
    }

    private fun performSearch(query: String) {
        val q = query.trim()
        val hidden = prefs.getHiddenPackages()
        val visibleApps = allInstalledApps.filter { it.packageName !in hidden }
        val matchedApps = if (q.isEmpty()) visibleApps else visibleApps.filter {
            it.label.contains(q, true) || it.packageName.contains(q, true)
        }
        val matchedChannels = if (q.isEmpty()) allLiveChannels.take(12) else allLiveChannels.filter {
            it.name.contains(q, true) || it.group.contains(q, true)
        }.take(30)
        val matchedYt = if (q.isEmpty()) allYouTubeVideos.take(10) else allYouTubeVideos.filter {
            it.title.contains(q, true) || it.channelName.contains(q, true)
        }

        tvSearchYtCount.visibility = if (matchedYt.isEmpty()) View.GONE else View.VISIBLE
        rvSearchYoutube.visibility = if (matchedYt.isEmpty()) View.GONE else View.VISIBLE
        tvSearchYtCount.text = "YouTube Videos (${matchedYt.size})"
        searchYtAdapter.submitList(matchedYt)

        tvSearchChannelCount.visibility = if (matchedChannels.isEmpty()) View.GONE else View.VISIBLE
        rvSearchChannels.visibility = if (matchedChannels.isEmpty()) View.GONE else View.VISIBLE
        tvSearchChannelCount.text = "Live TV Channels (${matchedChannels.size})"
        searchChannelsAdapter.submitList(matchedChannels)

        tvSearchResultCount.text = "Apps (${matchedApps.size})"
        searchAppsAdapter.submitList(matchedApps)
    }

    // ==================== NAVIGATION & SYSTEM ====================
    private fun selectTab(tabIndex: Int) {
        currentTab = tabIndex
        if (searchBarContainer.visibility == View.VISIBLE) toggleSearch(false)

        val darkText = Color.parseColor("#090D16")
        val whiteText = Color.WHITE
        val topTabs = listOf(tabHome, tabMovies, tabSeries, tabLive, tabApps, tabLibrary)
        topTabs.forEachIndexed { i, tv ->
            tv.isSelected = (i == tabIndex)
            tv.setTextColor(if (tv.isSelected || tv.hasFocus()) darkText else whiteText)
        }

        sideHome.isSelected = (tabIndex == 0)
        sideMovies.isSelected = (tabIndex == 1)
        sideSeries.isSelected = (tabIndex == 2)
        sideLive.isSelected = (tabIndex == 3)
        sideApps.isSelected = (tabIndex == 4)

        val showHero = (tabIndex == 0 && prefs.showHeroBanner && !prefs.isUltraLiteMode)
        heroBackdropLayer.visibility = if (showHero) View.VISIBLE else View.GONE
        heroOverlayBox.visibility = if (showHero) View.VISIBLE else View.GONE

        viewHome.visibility = if (tabIndex == 0) View.VISIBLE else View.GONE
        viewCinema.visibility = if (tabIndex == 1 || tabIndex == 2) View.VISIBLE else View.GONE
        viewLive.visibility = if (tabIndex == 3) View.VISIBLE else View.GONE
        viewApps.visibility = if (tabIndex == 4) View.VISIBLE else View.GONE
        viewLibrary.visibility = if (tabIndex == 5) View.VISIBLE else View.GONE
        viewSearchResults.visibility = View.GONE

        val activeView = when (tabIndex) {
            0 -> viewHome
            1, 2 -> viewCinema
            3 -> viewLive
            4 -> viewApps
            else -> viewLibrary
        }
        Animation4D.animateTabEntrance(activeView, prefs.isUltraLiteMode || !prefs.enable4dAnimations)

        if (tabIndex == 1) {
            tvCinemaTitle.text = "Movies & 4K Blockbuster Trailers"
            refreshUiLists()
            refreshCinemaTabContent()
        } else if (tabIndex == 2) {
            tvCinemaTitle.text = "Web Series, Music & Entertainment"
            refreshCinemaTabContent()
        } else if (tabIndex == 3) {
            refreshUiLists()
            refreshChannelLists()
        } else if (tabIndex == 4) {
            updateFilterSelection()
            refreshAppsGrid()
        } else if (tabIndex == 5) {
            updateDeviceHealthCard()
            refreshFavoriteMovies()
        }
    }

    private fun updateFilterSelection() {
        val darkText = Color.parseColor("#090D16")
        val whiteText = Color.WHITE
        listOf(btnFilterAll, btnFilterTv, btnFilterSideload).forEachIndexed { idx, tv ->
            tv.isSelected = (currentAppFilter == idx)
            tv.setTextColor(if (tv.isSelected || tv.hasFocus()) darkText else whiteText)
        }
    }

    private fun showBootModeDialog() {
        val modes = arrayOf(
            "Instant UltraTV Pro Home (Default & Recommended)",
            "Auto-Launch Selected App (with safe Home fallback)",
            "DTH Mode: Auto-Play Last Watched IPTV Channel",
            "Auto-Launch MovieBox TV (with safe Home fallback)"
        )
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("TV Startup Mode")
            .setSingleChoiceItems(modes, prefs.bootMode) { dialog, which ->
                dialog.dismiss()
                if (which == 1) {
                    val names = allInstalledApps.map { it.label }.toTypedArray()
                    AlertDialog.Builder(this, R.style.GtvDialogTheme)
                        .setTitle("Choose Auto-Launch App")
                        .setItems(names) { _, idx ->
                            prefs.autoLaunchPackage = allInstalledApps[idx].packageName
                            prefs.bootMode = 1
                            Toast.makeText(this, "Auto-Launch: ${allInstalledApps[idx].label}", Toast.LENGTH_LONG).show()
                        }.show()
                } else {
                    prefs.bootMode = which
                    Toast.makeText(this, "Boot Mode saved!", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showChangePinDialog() {
        val input = EditText(this).apply {
            hint = "New 4-digit PIN"
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE)
            setHintTextColor(Color.parseColor("#94A3B8"))
            setPadding(32, 24, 32, 24)
        }
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Set Kids Lock PIN")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val p = input.text?.toString()?.trim().orEmpty()
                if (p.length >= 4) {
                    prefs.kidsPin = p.take(4)
                    Toast.makeText(this, "PIN updated!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showThemePicker() {
        val names = themes.map { it.first }.toTypedArray()
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Choose 3D Theme")
            .setSingleChoiceItems(names, prefs.themeIndex) { d, which ->
                prefs.themeIndex = which
                applyUserPreferences()
                d.dismiss()
            }
            .show()
    }

    private fun showUnhideAppsDialog() {
        val hidden = prefs.getHiddenPackages().toList()
        if (hidden.isEmpty()) {
            Toast.makeText(this, "No hidden apps", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = hidden.map { pkg -> allInstalledApps.firstOrNull { it.packageName == pkg }?.label ?: pkg }.toTypedArray()
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Unhide App")
            .setItems(labels) { _, which ->
                val set = prefs.getHiddenPackages()
                set.remove(hidden[which])
                prefs.saveHiddenPackages(set)
                refreshUiLists()
            }
            .setNeutralButton("Unhide All") { _, _ ->
                prefs.saveHiddenPackages(emptySet())
                refreshUiLists()
            }
            .show()
    }

    private fun applyUserPreferences() {
        val idx = prefs.themeIndex.coerceIn(0, themes.lastIndex)
        rootContainer.setBackgroundResource(themes[idx].second)
        btnRamBoost.visibility = if (prefs.showRamMeter) View.VISIBLE else View.GONE
        leftSidebarContainer.visibility = if (prefs.showLeftSidebar) View.VISIBLE else View.GONE
        movieBoxSection.visibility = if (prefs.showMovieBoxRow) View.VISIBLE else View.GONE

        val appCols = prefs.gridColumns.coerceIn(4, 6)
        val chCols = (appCols - 1).coerceIn(3, 4)
        (rvLiveChannelsGrid.layoutManager as? GridLayoutManager)?.spanCount = chCols
        (rvLibraryFavChannels.layoutManager as? GridLayoutManager)?.spanCount = chCols
        (rvSearchChannels.layoutManager as? GridLayoutManager)?.spanCount = chCols
        (rvLiveApps.layoutManager as? GridLayoutManager)?.spanCount = appCols
        (rvAllGrid.layoutManager as? GridLayoutManager)?.spanCount = appCols
        (rvLibraryFavorites.layoutManager as? GridLayoutManager)?.spanCount = appCols
        (rvSearchResults.layoutManager as? GridLayoutManager)?.spanCount = appCols
    }

    private fun boostRamNow() {
        MediaImageLoader.trimMemory()
        System.gc()
        mainHandler.postDelayed({
            val ram = getRamInfo()
            updateClockAndStatus()
            Toast.makeText(this, "Image Cache Trimmed • Available Memory: ${ram.first} MB / ${ram.second} MB", Toast.LENGTH_SHORT).show()
        }, 250L)
    }

    private fun showPerformanceTierDialog() {
        val options = arrayOf(
            "Auto-Detect for TV Hardware (Recommended)",
            "Ultra Lite Mode (512MB RAM — Zero Anim)",
            "Low RAM Mode (1GB RAM — Fast Scale)",
            "Balanced Mode (2GB RAM — Smooth 3D)",
            "Cinematic Mode (3GB+ RAM — Full 4D + Ken Burns)"
        )
        val currentIdx = if (prefs.performanceTier in 0..3) prefs.performanceTier + 1 else 0
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Performance Profile")
            .setSingleChoiceItems(options, currentIdx) { d, which ->
                prefs.performanceTier = if (which == 0) -1 else which - 1
                prefs.isUltraLiteMode = (which == 1)
                PerformanceTier.invalidateCache()
                val tier = PerformanceTier.resolve(this, prefs)
                MediaImageLoader.initForTier(tier)
                applyUserPreferences()
                d.dismiss()
                Toast.makeText(this, "Active Profile: ${tier.label}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showBackupRestoreDialog() {
        val options = arrayOf(
            "Save Backup to TV Storage (UltraTV_Pro_Backup.json)",
            "Restore Backup from TV Storage",
            "Copy Backup JSON to Clipboard"
        )
        AlertDialog.Builder(this, R.style.GtvDialogTheme)
            .setTitle("Backup & Restore Settings")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val res = BackupRestoreManager.saveBackupFile(this, prefs)
                        res.onSuccess { f -> Toast.makeText(this, "Saved: ${f.name}", Toast.LENGTH_LONG).show() }
                            .onFailure { e -> Toast.makeText(this, "Backup failed: ${e.message}", Toast.LENGTH_LONG).show() }
                    }
                    1 -> {
                        val res = BackupRestoreManager.restoreFromFile(this, prefs)
                        res.onSuccess { msg ->
                            applyUserPreferences()
                            refreshUiLists()
                            refreshChannelLists()
                            refreshFavoriteMovies()
                            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                        }.onFailure { e -> Toast.makeText(this, "Restore failed: ${e.message}", Toast.LENGTH_LONG).show() }
                    }
                    2 -> {
                        val json = BackupRestoreManager.exportToJson(prefs)
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        cm?.setPrimaryClip(ClipData.newPlainText("UltraTV Pro Backup", json))
                        Toast.makeText(this, "Backup JSON copied to clipboard!", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun updateClockAndStatus() {
        val now = Date()
        val timeFmt = if (prefs.is24HourClock) "HH:mm" else "h:mm a"
        tvClock.text = SimpleDateFormat(timeFmt, Locale.getDefault()).format(now)
        tvDate.text = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(now)

        val ram = getRamInfo()
        tvRamStatus.text = "${ram.first}MB"
        tvRamStatus.setTextColor(
            when {
                ram.first < 90 -> Color.parseColor("#FB7185")
                ram.first < 160 -> Color.parseColor("#FACC15")
                else -> Color.parseColor("#4ADE80")
            }
        )

        val (netType, isOnline) = getNetworkStatus()
        if (netType == "Ethernet") {
            ivWifi.setImageResource(R.drawable.ic_3d_ethernet)
            tvNetLabel.text = "ETH"
            tvNetLabel.setTextColor(Color.parseColor("#4ADE80"))
            ivWifi.alpha = 1.0f
        } else if (isOnline) {
            ivWifi.setImageResource(R.drawable.ic_3d_wifi)
            tvNetLabel.text = netType
            tvNetLabel.setTextColor(Color.parseColor("#4ADE80"))
            ivWifi.alpha = 1.0f
        } else {
            ivWifi.setImageResource(R.drawable.ic_3d_wifi)
            tvNetLabel.text = "OFF"
            tvNetLabel.setTextColor(Color.parseColor("#FB7185"))
            ivWifi.alpha = 0.45f
        }
    }

    private fun updateDeviceHealthCard() {
        val ram = getRamInfo()
        val (netType, isOnline) = getNetworkStatus()
        val ytCount = prefs.getYouTubeHistory().size
        val iptvCount = prefs.getIptvHistory().size
        tvDeviceHealth.text = buildString {
            appendLine("TV Model: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})")
            appendLine("Memory: ${ram.first} MB Free / ${ram.second} MB Total  |  Profile: ${PerformanceTier.resolve(this@MainActivity, prefs).label}")
            appendLine("Default Home: ${if (LauncherHomeManager.isDefaultHomeLauncher(this@MainActivity)) "ACTIVE" else "Not Set"}  |  Last Boot: ${prefs.getBootDiagnosticSummary()}")
            appendLine("Storage: ${getStorageSummary()}  |  Network: $netType (${if (isOnline) getLocalIpAddress() else "Offline"})")
            appendLine("Watch History Saved: ${prefs.getMovieBoxHistory().size} MovieBox  •  $ytCount YouTube  •  $iptvCount RAM PLAYER IPTV")
            append("Apps: ${allInstalledApps.size} Total (${allInstalledApps.count { !it.isTvApp }} Sideloaded)  |  M3U Channels: ${allLiveChannels.size}")
        }
    }

    private fun getRamInfo(): Pair<Long, Long> {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return Pair(mi.availMem / (1024L * 1024L), mi.totalMem / (1024L * 1024L))
    }

    private fun getStorageSummary(): String {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val availGb = stat.availableBytes / (1024.0 * 1024.0 * 1024.0)
            val totalGb = stat.totalBytes / (1024.0 * 1024.0 * 1024.0)
            String.format(Locale.US, "%.1f GB / %.1f GB free", availGb, totalGb)
        } catch (_: Throwable) { "Ready" }
    }

    private fun openSystemAction(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            searchBarContainer.visibility == View.VISIBLE -> toggleSearch(false)
            currentTab != 0 -> { selectTab(0); tabHome.requestFocus() }
            else -> tabHome.requestFocus()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (searchBarContainer.visibility != View.VISIBLE) {
            val digit = when (keyCode) {
                KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_NUMPAD_1 -> 1
                KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_NUMPAD_2 -> 2
                KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_NUMPAD_3 -> 3
                KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_NUMPAD_4 -> 4
                KeyEvent.KEYCODE_5, KeyEvent.KEYCODE_NUMPAD_5 -> 5
                KeyEvent.KEYCODE_6, KeyEvent.KEYCODE_NUMPAD_6 -> 6
                KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_NUMPAD_7 -> 7
                KeyEvent.KEYCODE_8, KeyEvent.KEYCODE_NUMPAD_8 -> 8
                KeyEvent.KEYCODE_9, KeyEvent.KEYCODE_NUMPAD_9 -> 9
                else -> 0
            }
            if (digit in 1..9) {
                val target = prefs.getSpeedDial(digit)
                if (target.startsWith("app:")) {
                    allInstalledApps.firstOrNull { it.packageName == target.removePrefix("app:") }?.let {
                        launchAppWithLockCheck(it); return true
                    }
                } else if (target.startsWith("ch:")) {
                    allLiveChannels.firstOrNull { it.streamUrl == target.removePrefix("ch:") }?.let {
                        playLiveChannel(it, null); return true
                    }
                }
            }
        }
        when (keyCode) {
            KeyEvent.KEYCODE_MENU -> { showLauncherSettingsDialog(); return true }
            KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_TV -> { selectTab(3); return true }
            KeyEvent.KEYCODE_SEARCH -> { toggleSearch(true); return true }
        }
        return super.onKeyDown(keyCode, event)
    }
}
